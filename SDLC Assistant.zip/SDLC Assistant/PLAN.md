# SDLC-Banking-Assistant — Project Implementation Plan

**Product:** VS Code extension for a digital core-banking DevEx team
**AI Runtime:** GitHub Copilot only, via the native VS Code Language Model API (`vscode.lm`). No external LLM APIs, no LangChain, no local models.
**Pipeline:** WSDL/XSD + NCP rules → Swagger 2.0 (version-locked) → Lambda handler service code + mocha/c8 tests, delivered into a fixed repo layout (`infra/` + `service/lambda-functions/`).

> **Corrected against the real repo:** the two Phase-6 assumptions below were revised after examining an actual human-built generated repo (see `GENERATION_SPEC.md`, which cites file/line evidence for every rule). Routing is done by API Gateway via the swagger itself (`x-amazon-apigateway-integration`) — **there is no Express**; the service code is plain `exports.<operationId>Lambda` handlers. **Generated-repo tests are mocha/chai/sinon/proxyquire with c8 coverage, not Jest** — Jest is retained only for the *extension's own* test suite (`test/unit`, `test/integration`) and is never a dependency of a generated repo. §2.2, Phase 6, and §4 below reflect this correction; it is already implemented in `src/generators/repoGenerator.ts` and `src/templates/service/*.hbs`.

---

## 1. System Architecture & Tech Stack

### 1.1 Core principle: AI routes, tools decide

The LLM never authors the final Swagger or code. It acts as an **orchestrating router** that decides *which deterministic tool to call next* and assembles *small, validated JSON mappings*. All file parsing and all code emission is done by local TypeScript tools. This eliminates hallucinated field names, invented endpoints, and spec-version drift.

```
┌─────────────────────────────────────────────────────────────────┐
│                     VS Code Extension Host                      │
│                                                                 │
│  ┌───────────────┐    selectChatModels({vendor:'copilot'})      │
│  │  Orchestrator │◄────────────────────────────────────────┐    │
│  │  (agent loop) │                                         │    │
│  └──────┬────────┘         GitHub Copilot (user's own sub) │    │
│         │ sendRequest(messages, { tools }, token)          │    │
│         │◄── LanguageModelChatResponse.stream ─────────────┘    │
│         │      ├─ LanguageModelTextPart                         │
│         │      └─ LanguageModelToolCallPart ──┐                 │
│         │                                     ▼                 │
│  ┌──────┴──────────────────────────────────────────────────┐   │
│  │        Native LM Tools (vscode.lm.registerTool)         │   │
│  │                                                          │   │
│  │  read_wsdl_schema   → fast-xml-parser (deterministic)    │   │
│  │  query_ncp_rules    → mammoth + regex extraction         │   │
│  │  generate_artifacts → Zod validate → Handlebars render   │   │
│  └──────────────────────────────────────────────────────────┘   │
│         │ LanguageModelToolResultPart fed back into messages    │
│         ▼                                                       │
│  Workspace FS: swagger.json (locked "swagger": "2.0"),          │
│  Lambda handlers, mocha suites → fixed target repo layout       │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 The Agentic loop with `vscode.lm`

1. **Model acquisition**
   ```typescript
   const [model] = await vscode.lm.selectChatModels({ vendor: 'copilot' });
   if (!model) { /* prompt user to sign in / enable Copilot */ }
   ```
   First `sendRequest` triggers VS Code's one-time consent dialog — no auth code to write; the user's Copilot subscription is the credential.

2. **Request with tools attached**
   ```typescript
   const response = await model.sendRequest(messages, {
     tools: [readWsdlTool, queryNcpTool, generateArtifactsTool],
     toolMode: vscode.LanguageModelChatToolMode.Auto,
     justification: 'Generate Swagger 2.0 + Lambda service code from legacy banking specs'
   }, cancellationToken);
   ```

3. **Stream handling** — iterate `response.stream`; collect `LanguageModelTextPart` for progress display and `LanguageModelToolCallPart` for tool dispatch.

4. **Tool dispatch** — for each tool call, invoke via `vscode.lm.invokeTool(call.name, { input: call.input, toolInvocationToken })`. The tool runs **locally, deterministically**.

5. **Loop closure** — append the assistant turn (with tool-call parts) and a `LanguageModelChatMessage.User` containing `LanguageModelToolResultPart`s, then `sendRequest` again. Repeat until the model returns text-only (done) or a max-iteration cap (default 8) is hit.

6. **Hard guardrail** — the *final* artifact write happens only inside `generate_artifacts`, which validates the model's JSON mapping with Zod and renders Handlebars templates. A rejected schema returns a structured error to the model for one retry; two failures aborts with a user-facing diff of what failed validation.

### 1.3 Tech stack summary

| Layer | Choice | Why |
|---|---|---|
| Extension language | TypeScript (strict mode) | Type safety across tool I/O contracts |
| AI access | `vscode.lm` + `contributes.languageModelTools` | Only permitted channel; rides user's Copilot seat |
| XML parsing | `fast-xml-parser` | Deterministic WSDL/XSD → JSON, no LLM involvement |
| DOCX ingestion | `mammoth` | NCP .docx → raw text for regex extraction |
| Rules extraction | Native RegExp library (curated pattern set) | Zero-token extraction of headers/constraints |
| Schema validation | `zod` (tool I/O) + `ajv-draft-04` (Swagger 2.0 JSON Schema) | Swagger 2.0 uses JSON Schema draft-04 |
| Codegen | `handlebars` templates | Deterministic, reviewable, versioned in-repo |
| Output formatting | `prettier` (programmatic API) | Consistent generated code style |
| Testing (extension) | `jest` + `@vscode/test-electron` | Unit + integration |
| Packaging | `esbuild` + `@vscode/vsce` | Fast bundling, marketplace-ready VSIX |

---

## 2. Directory Structure

### 2.1 Extension repository

```
sdlc-banking-assistant/
├── package.json                  # contributes.languageModelTools, commands, chatParticipants
├── tsconfig.json                 # strict: true
├── esbuild.js
├── .vscodeignore
├── src/
│   ├── extension.ts              # activate(): register tools, commands, participant
│   ├── orchestrator/
│   │   ├── agentLoop.ts          # sendRequest loop, stream handling, iteration cap
│   │   ├── prompts.ts            # minimal system prompts (token-budgeted)
│   │   └── tokenBudget.ts        # model.countTokens pre-flight checks
│   ├── tools/
│   │   ├── readWsdlSchema.ts     # LanguageModelTool<ReadWsdlInput>
│   │   ├── queryNcpRules.ts      # LanguageModelTool<QueryNcpInput>
│   │   └── generateArtifacts.ts  # LanguageModelTool<GenerateInput>
│   ├── parsers/
│   │   ├── wsdlParser.ts         # fast-xml-parser config + WSDL walk
│   │   ├── xsdTypeMapper.ts      # xsd:string → string, xsd:decimal → number, etc.
│   │   ├── ncpExtractor.ts       # regex pattern registry for headers/constraints
│   │   └── docxReader.ts         # mammoth wrapper
│   ├── schemas/
│   │   ├── toolContracts.ts      # Zod schemas for every tool's input/output
│   │   ├── swaggerMapping.ts     # Zod schema the LLM's JSON mapping must satisfy
│   │   └── swagger-2.0-schema.json  # official draft-04 schema for final validation
│   ├── generators/
│   │   ├── swaggerReader.ts      # swagger.json → codegen model (operations, dereferenced body schemas)
│   │   ├── versionLock.ts        # assertVersionLock("2.0") gate
│   │   ├── swaggerGenerator.ts   # mapping JSON → swagger.json ("2.0" hard-coded)
│   │   ├── repoGenerator.ts      # swagger.json → full Lambda service repo (no Express; see §2.2)
│   │   └── naming.ts             # operationId → env-var name / kebab-case / sample payload — fixed transforms only, never abbreviation
│   ├── templates/
│   │   ├── swagger/skeleton.hbs        # contains literal "swagger": "2.0"
│   │   └── service/                    # renders the §2.2 tree — Lambda handlers + mocha tests, not Express/Jest
│   │       ├── index.js.hbs, serviceStarter.js.hbs, properties.js.hbs
│   │       ├── schemaValidator.js.hbs, mapResponse.js.hbs, headerMapper.js.hbs, framework.js.hbs (STUB)
│   │       ├── schemaTest.js.hbs, starterTest.js.hbs, headerMapperTest.js.hbs   # mocha, per operation
│   │       └── package.json.hbs, envExample.hbs, repoReadme.md.hbs
│   └── utils/
│       ├── cache.ts              # content-hash cache of parsed WSDL/NCP
│       ├── rateLimiter.ts        # backoff + request coalescing
│       └── logger.ts             # OutputChannel logging
├── test/
│   ├── unit/                     # parsers, generators (no VS Code host needed)
│   ├── integration/              # tool registration, agent loop with mocked lm
│   └── fixtures/                 # sample WSDLs, XSDs, NCP docs, golden outputs
└── docs/
    └── ARCHITECTURE.md
```

### 2.2 Generated output repository (fixed — never restructured by the tool)

The scaffolder emits exactly this layout, matching the real human-built reference repo cited in `GENERATION_SPEC.md`. There is **no Express** and **no per-function subfolder** — `service/lambda-functions/` is flat, one folder for the whole API, dispatched by API Gateway via the swagger itself. `infra/` is created as an untouched placeholder; the extension never writes infra logic into it.

```
<repo-name>/                          # user-supplied at generation time
├── README.md
├── .gitignore
├── .env.example                      # documents every <PREFIX>_HOST / <OPERATION>_PATH placeholder
├── swagger.json                      # "swagger": "2.0" — version-locked, never upgraded
├── infra/                            # placeholder only — owned by platform team
│   └── .gitkeep
└── service/
    └── lambda-functions/              # FLAT — one folder for the whole API, no per-function subfolder
        ├── index.js                   # one exports.<operationId>Lambda per swagger operation
        ├── properties.js              # status/message constants + sanitizeList
        ├── package.json               # mocha/chai/c8 test scripts; ajv runtime dep
        ├── resources/
        │   ├── schema/<operationId>Schema.json     # body schema, dereferenced byte-for-byte, per operation
        │   └── validator/schemaValidator.js         # Ajv wrapper
        ├── service/
        │   ├── <operationId>ServiceStarter.js        # validate → TODO(BUSINESS-LOGIC) stub, per operation
        │   ├── mapping/mapResponse.js                 # success/error envelope builders from swagger definitions
        │   └── sub/headerMapper.js                    # x-request-id extraction (case-insensitive)
        ├── common/logger/framework.js   # STUB — placeholder for the internal shared logger; a human wires in the real library
        └── test/
            ├── headerMapper.test.js
            ├── <operationId>Schema.test.js            # per operation — missing-required-field cases from the schema
            └── <operationId>Starter.test.js           # per operation
```

Backend integration (authentication, encryption, token caching, Secrets Manager/DynamoDB, Dynatrace) is explicitly **not** generated — those land as `TODO(BUSINESS-LOGIC)` markers inside each `ServiceStarter.js`, per `GENERATION_SPEC.md`'s "what must not be generated" list. A human completes them; the generator never invents business logic.

Generated Lambda handler pattern (Placeholder Strategy):

```javascript
// index.js — generated, do not hand-edit. Routing is API Gateway, not Express.
exports.listMortgageStatementLambda = (event, context, callback) => {
  var args = { headers: event.headers, event, context };
  var options = { args, override: true, sanitizeArray: properties.sanitizeList };
  framework.execute(event, context, callback, listMortgageStatementService, options);
};
```

```javascript
// service/<operationId>ServiceStarter.js — generated, do not hand-edit
var HOST = process.env.MORTGAGELOANSTATEMENT_HOST || '';
var LISTMORTGAGESTATEMENT_PATH = process.env.LISTMORTGAGESTATEMENT_PATH || '/placeholder/list-mortgage-statement';
```

Every placeholder is also written to `.env.example` with the source WSDL/swagger operation it maps to, so cross-team approval later is a config change, not a code change.

---

## 3. Phase-by-Phase Execution Plan

### Phase 0 — Scaffold & toolchain (Days 1–2)
- `yo code` (TypeScript) scaffold; enable `"strict": true`.
- Set `engines.vscode` to `^1.95.0`+ (the `languageModelTools` contribution point and `vscode.lm.registerTool` were finalized in 1.95; `sendRequest` itself is available from 1.90).
- Wire esbuild bundling, ESLint, Jest, CI (lint + unit tests on PR).
- **Exit criteria:** F5 launches Extension Development Host; hello-world command runs.

### Phase 1 — Copilot access via `vscode.lm` (Days 3–5)
- Implement `modelProvider.ts`: `selectChatModels({ vendor: 'copilot' })` with graceful handling of the empty-array case (Copilot not installed / not signed in / disabled by org policy) → actionable notification.
- Handle `LanguageModelError` causes: `NoPermissions` (consent denied), `Blocked` (quota/content), `NotFound` (model gone mid-session).
- Prove one round-trip `sendRequest` with a trivial prompt; render `response.stream` text into an OutputChannel.
- **Exit criteria:** consent dialog flow works; errors produce clear user guidance; zero tokens spent beyond the smoke test.

### Phase 2 — Deterministic parsers (Days 6–12) — *no AI involved*
- `wsdlParser.ts`: fast-xml-parser with `ignoreAttributes: false`, `preserveOrder` where needed; walk `definitions → portType → operation → message → part`, resolve XSD `complexType`/`element` refs (including cross-file `xsd:import`).
- `xsdTypeMapper.ts`: exhaustive XSD→Swagger-2.0 primitive map (`xsd:decimal → number/format:double`, `xsd:date → string/format:date`, `maxLength/pattern/enumeration → Swagger constraints`). Names copied byte-for-byte from source — never re-cased.
- `ncpExtractor.ts`: regex pattern registry (versioned, unit-tested) for mandatory headers, field constraints, error codes; `docxReader.ts` via mammoth for .docx NCP inputs.
- `cache.ts`: SHA-256 content hash → parsed JSON, persisted in `workspaceState`.
- **Exit criteria:** golden-file tests — every fixture WSDL/NCP parses to a stable JSON snapshot; 100% of type mappings covered.

### Phase 3 — LM Tool registration (Days 13–17)
- Declare all three tools in `package.json`:
  ```jsonc
  "contributes": {
    "languageModelTools": [
      {
        "name": "sdlc-banking_readWsdlSchema",
        "toolReferenceName": "readWsdl",
        "displayName": "Read WSDL Schema",
        "modelDescription": "Deterministically parses a WSDL/XSD file and returns operations, messages, and typed fields as strict JSON. ALWAYS use this instead of reading XML yourself.",
        "canBeReferencedInPrompt": true,
        "inputSchema": { "type": "object", "properties": { "fileUri": { "type": "string" }, "operation": { "type": "string" } }, "required": ["fileUri"] }
      }
      // + sdlc-banking_queryNcpRules, sdlc-banking_generateArtifacts
    ]
  }
  ```
- Implement each as `vscode.LanguageModelTool<T>`: `prepareInvocation` (confirmation message for `generate_artifacts` since it writes files) + `invoke` (Zod-validate input → run parser → return `LanguageModelToolResult`).
- Register in `activate()` with `vscode.lm.registerTool(name, instance)`.
- **Exit criteria:** tools invocable standalone via a debug command; malformed inputs rejected by Zod with machine-readable errors.

### Phase 4 — Orchestrator agent loop (Days 18–24)
- `agentLoop.ts`: the sendRequest → stream → tool-call → tool-result → re-send loop from §1.2, with iteration cap, cancellation token plumbing, and per-step progress via `vscode.window.withProgress`.
- `toolMode: Auto`; force specific tools (`Required`) only for the first step (schema read) to prevent the model free-styling.
- System prompt (< 300 tokens): role, the three tools, output contract ("respond ONLY with JSON matching the provided schema"), and the version-lock rule.
- Commands: **SDLC: Generate Swagger 2.0**, **SDLC: Generate Service Repo**, **SDLC: End-to-End** — user picks WSDL/NCP/output; loop runs; a results webview (`src/views/summaryPanel.ts`) shows what was generated and every placeholder still needing config.
- **Frontend (added beyond the original phase plan):** an **Endpoints sidebar view** (`src/views/endpointTreeProvider.ts`, Activity Bar → "SDLC Banking") lists every WSDL operation and its approval state, as a persistent alternative to the sequential input-box flow in `endpointApproval.ts`. It produces the identical `ApprovedOperation[]` shape, so it supplies approval — it never bypasses the approval gate itself.
- **Exit criteria:** end-to-end run on fixture specs produces a validated mapping JSON with zero hand-edits.

### Phase 5 — Swagger 2.0 generation with version lock (Days 25–29)
- The LLM outputs only a **mapping JSON** (operation → path/verb/params/responses selections) validated against `swaggerMapping.ts` (Zod).
- `swaggerGenerator.ts` merges mapping + parsed WSDL types into `skeleton.hbs`, where `"swagger": "2.0"` is a **template literal** — the model physically cannot change it, and no OpenAPI 3.x conversion path exists in the codebase.
- Post-generation gate, all local: `ajv-draft-04` against the official Swagger 2.0 JSON Schema, plus `@apidevtools/swagger-parser` `validate()`; assert `doc.swagger === '2.0'` and fail hard otherwise.
- **Exit criteria:** generated swagger.json validates; a mutation test proving the pipeline rejects any `openapi: 3.x` output.

### Phase 6 — Code & test generation into the fixed repo layout (Days 30–36)
- `repoGenerator.ts` creates the §2.2 tree exactly (including `infra/.gitkeep` — nothing else in `infra/`), driven by `swaggerReader.ts` (dereferences body schemas from swagger `definitions`) and `naming.ts` (operationId → env-var name / kebab-case, fixed transforms only, never abbreviation heuristics).
- Per swagger operation: `index.js` gets one `exports.<operationId>Lambda` dispatched through `framework.execute(...)` (API Gateway does the routing — **no Express**); `service/<operationId>ServiceStarter.js` gets a validate → `TODO(BUSINESS-LOGIC)` stub; `resources/schema/<operationId>Schema.json` is the body definition dereferenced byte-for-byte. Every route/host is `process.env.<PREFIX>_HOST` / `process.env.<OPERATION>_PATH || '/placeholder/<kebab-name>'`; `.env.example` regenerated with the full placeholder inventory.
- Test generation emits **mocha/chai suites, not Jest**, per operation: schema-validation cases derived directly from the schema's `required[]` (missing required field → reject), plus a starter test per operation. Coverage via `c8`, matching the reference repo's `package.json` scripts exactly (`GENERATION_SPEC.md`).
- All output through prettier; idempotent regeneration (stable ordering, no timestamps in output).
- **Exit criteria:** the generated repo's own `npm test` (mocha + c8) passes green with zero manual edits. (Jest is used only to test the extension's own generator code, in `test/unit`.)

### Phase 7 — Hardening, UX & release (Days 37–42)
- Rate-limit resilience (see §5) wired into the loop.
- Telemetry-free audit log: every generation writes a local manifest (source file hashes, template versions, mapping JSON) for reproducibility/compliance review.
- Walkthrough (`contributes.walkthroughs`), README, CHANGELOG; package with `vsce`; publish to internal marketplace/private VSIX feed.
- **Exit criteria:** clean install on a teammate's machine → spec-to-repo generation in one command.

---

## 4. Dependencies

### Extension — runtime (`dependencies`)
| Package | Purpose |
|---|---|
| `fast-xml-parser` | Deterministic WSDL/XSD parsing |
| `mammoth` | NCP .docx → text extraction |
| `handlebars` | Code/spec template rendering |
| `zod` | Tool I/O and mapping-JSON validation |
| `ajv` + `ajv-draft-04` | Swagger 2.0 (draft-04) schema validation |
| `@apidevtools/swagger-parser` | Semantic Swagger validation ($ref resolution) |
| `prettier` | Formatting generated output |

### Extension — dev (`devDependencies`)
`typescript`, `@types/vscode`, `@types/node`, `esbuild`, `eslint` + `@typescript-eslint/*`, `jest`, `ts-jest`, `@vscode/test-electron`, `@vscode/vsce`.

### Generated repo (written into its `package.json.hbs`)
Runtime: `ajv` (+ `json-schema-ref-parser` for `$ref` dereferencing in the validator). Dev: `mocha`, `chai`, `sinon`, `proxyquire`, `c8`. **No `express`, no `dotenv`, no `jest`, no `supertest`** — corrected per `GENERATION_SPEC.md` against the real reference repo's `package.json`.

**No AI SDKs anywhere** — no `openai`, no `langchain`, no `@aws-sdk/client-bedrock*`. The only AI surface is the `vscode.lm` namespace, which ships with VS Code itself.

---

## 5. Copilot Rate-Limit Mitigation

Copilot chat requests draw from the user's per-seat quota, and the LM API enforces fairness limits on extension-originated requests. The design goal: **most work costs zero tokens**.

1. **Local-first pipeline.** Parsing (Phase 2) and generation (Phases 5–6) are 100% local. The LLM is consulted only for the mapping decisions in between — typically 2–4 `sendRequest` calls per full generation, not dozens.
2. **Micro-prompts with JSON-only contracts.** System prompt under 300 tokens; per-request user content is the *summarized* tool output (field names + types), never raw WSDL XML or full NCP text. `query_ncp_rules` regex-filters documents locally so only matched rules (usually < 1 KB) ever enter a prompt.
3. **Pre-flight token budgeting.** `tokenBudget.ts` calls `model.countTokens()` before every send; if a payload exceeds budget (e.g., a 40-operation WSDL), the orchestrator shards by operation group and requests mappings per shard.
4. **Content-hash caching.** Parsed WSDL/NCP JSON and accepted mapping JSON are cached by source-file SHA-256. Regenerating code after a template tweak costs **zero** Copilot requests — only a changed source spec triggers new AI calls.
5. **Iteration cap + `Required` tool mode.** Capping the agent loop (8 rounds) and forcing the first tool call prevents exploratory-chatter loops that burn quota without progress.
6. **Backoff + coalescing.** `rateLimiter.ts` catches `LanguageModelError`/`Blocked`, applies exponential backoff (1s → 2s → 4s, 3 retries), queues concurrent generation commands so only one agent loop runs at a time.
7. **Single-shot retry on validation failure.** If Zod rejects the model's mapping, exactly one corrective re-prompt is sent containing only the Zod error paths — not the whole conversation. Second failure aborts to a human-readable report instead of spending more tokens.
8. **No background polling.** The extension never calls the LM outside an explicit user command; no on-save or on-type triggers.

---

## Guardrail summary (non-negotiables)

- LLM output is always **JSON mapping data**, never final code or full Swagger documents.
- `"swagger": "2.0"` is hard-coded in the template; a post-gen assertion rejects anything else. No upgrade/conversion code exists in the repo.
- All names, types, and constraints originate from `fast-xml-parser`/regex extraction — byte-for-byte from source files.
- Every generated route path is an env-var placeholder with a documented `.env.example` entry.
- `infra/` is scaffolded empty and never written to again.
- The generated repo is plain Lambda handlers (`exports.<operationId>Lambda`) dispatched by API Gateway — **no Express is ever emitted**, and no `jest`/`supertest` dependency is ever written into a generated repo's `package.json`. Jest is exclusively for the extension's own tests. (See `GENERATION_SPEC.md`.)
- Every tool input/output crosses a Zod boundary; every generated repo must pass its own mocha/c8 suite before the run is reported successful.
