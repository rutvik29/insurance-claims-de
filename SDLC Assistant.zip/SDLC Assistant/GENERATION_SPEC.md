# Code Generation Spec — derived from the real repo (CG2V_SCCG-Mtg-ln-stmt-Fn-CDK_26777-sit4)

This spec is based ONLY on what exists in the human-built repo. Every generation rule below cites its evidence. Anything not derivable from the swagger is classified as **CONFIG** (asked from the user) or **STUB** (emitted as an explicit TODO skeleton) — never invented.

## Corrections to the original plan (important)

The real repo invalidates two of my Phase-6 assumptions:

1. **There is no Express.** Routing is done by API Gateway via the swagger itself (`x-amazon-apigateway-integration`, `aws_proxy`, in `infra/lib/swagger-api.ts`). The service code is plain **AWS Lambda handlers**: `exports.<name>Lambda = (event, context, callback)` in `index.js`, dispatched through the internal logger framework's `framework.execute(...)`.
2. **Generated-repo tests are mocha/chai/sinon/proxyquire with c8 coverage** (see `service/lambda-functions/package.json` scripts), not Jest. Jest stays only in the *extension's* own test suite and in `infra/jest.config.js`.

## Real repo structure (observed)

```
<repo>/
├── .gitignore, README.md, build.sh, buildspec.yml, controller.json
├── infra/                                  # CDK TypeScript (platform-owned)
│   ├── cdk.json, package.json, tsconfig.json, jest.config.js, README.md
│   └── lib/{common_stack, db_stack, function_stack, iam_stack,
│            operations_stack, swagger-api, tags}.ts
└── service/lambda-functions/               # FLAT — one folder for the whole API
    ├── index.js                            # one exports.<opId>Lambda per swagger operation
    ├── properties.js                       # message constants + sanitizeList
    ├── package.json                        # mocha/c8 tests, eslint tabs/double-quotes
    ├── buildspec.yml
    ├── setupDynatraceLambdaTracing.js
    ├── resources/
    │   ├── schema/<op>Schema.json          # standalone JSON Schema per operation body
    │   └── validator/schemaValidator.js    # Ajv + json-schema-ref-parser
    ├── service/
    │   ├── <operation>ServiceStarter.js    # one per operation: validate -> business flow
    │   ├── <Op>Function.js                 # backend call helpers
    │   ├── mapping/{AuthReqMapping, mapResponse}.js
    │   ├── sub/{convertToJSON, headerMapper}.js
    │   └── util/{DBEncryption, SHA256Hashing, SM1.., SM2..}.js
    ├── common/{logger/*, ECIFtoCG/*}       # shared framework library (copied, not generated)
    ├── Encryption/smartcore-crypto-*.js    # shared crypto library (copied, not generated)
    └── test/*.test.js                      # mocha, one file per service module
```

## What the generator must produce from the swagger — with evidence

| Artifact | Rule | Evidence |
|---|---|---|
| `resources/schema/<operationId>Schema.json` | Take the operation's `in: body` parameter `$ref`, dereference it against `definitions`, emit as standalone JSON Schema. Preserve `type/required/properties/description` **byte-for-byte**. | `listMtgStmtSchema.json` = `productAdapterRequest` definition; `rtvMtgStmtSchema.json` = `streamingAdapterRequest` (same required[], same descriptions) |
| `index.js` | One `exports.<operationId>Lambda` per swagger operation, building `args` (headers, event, context + AWS clients) and delegating to `framework.execute(event, context, callback, <starter>, options)` with `sanitizeArray: properties.sanitizeList`. | `index.js`: `listMortgageStatementLambda`, `retrieveMortgageStmtLambda` ↔ swagger `operationId`s `listMortgageStatement`, `retrieveMortgageStmt` |
| `service/<operationId>ServiceStarter.js` | Skeleton per operation: read `event.body`, JSON-parse, run `schemaValidator(inputreq, schema)` with the operation's schema, reject via `mapResponse.schemaErrorResponse`, resolve via mapped success response. Business flow beyond validation = **STUB** (TODO). | `listMortgageStatementServiceStarter.js` lines 1–75 (validation part is mechanical; auth/hash/DynamoDB flow is business logic) |
| Env-var placeholders | `process.env.<SERVICE>_HOST` + one `process.env.<OPERATION>_PATH` per operation. Never hard-code endpoints. Document each in README/.env.example. Values come from SSM in infra (`function_stack.ts`). | `MORTGAGELOANSTATEMENT_HOST`, `LISTMORTGAGESTATEMENT_PATH`, `RETRIEVEMORTGAGESTMT_PATH`; `function_stack.ts:158-160` reads them from SSM |
| Correlation-ID handling | Required header `x-request-id` (from swagger `parameters`) → `headerMapper.getCorrIdFromHeader(event)`, checked case-insensitively, fallback to `framework.getCorrelationId()`. Echo back in response headers. | `sub/headerMapper.js`; swagger 200/400 responses declare `x-request-id` response header |
| Response envelopes | Success/error response shapes come from swagger `definitions` (`productResponse` → `{result{code,status,messages,resultDetails}, ...}`, `errorResponse` → RFC-7807-style `{type,title,detail,status,instance,resultDetails}`). `mapResponse.js` builders return `{statusCode, headers:{x-request-id}, body: JSON.stringify(...), isBase64Encoded}`. | `mapping/mapResponse.js` `SuccessResponse`/`errorResponse` mirror the swagger definitions exactly |
| Status-code catalogue | Swagger declares 200,400,401,403,404,415,429,500,502,504 — all non-200s `$ref: errorResponse`. Generated `properties.js` constants and mapResponse builders must cover these codes only. | swagger-api.ts `responses` blocks (identical for both operations) |
| `properties.js` | Constants file with status strings + `sanitizeList`. Sanitize entries for every request/response field the swagger marks as sensitive **cannot be inferred** → seed with body property names, rest = CONFIG. | `properties.js` |
| `test/<module>.test.js` | mocha `describe/it` per generated module; schema-validation tests derive cases directly from the schema's `required[]` (missing required field → reject). | `test/*.test.js`, `package.json` test script (`c8 ... mocha --recursive ./test`) |
| `service/lambda-functions/package.json` | mocha/chai/sinon/proxyquire/c8 devDeps; `ajv`, `json-schema-ref-parser` runtime deps (validator needs them); eslint config w/ tabs + double quotes + security plugin. | observed package.json |

## What must NOT be generated (copied or configured, never invented)

- `common/logger/*`, `common/ECIFtoCG/*`, `Encryption/*` — internal shared libraries. **COPY** from a designated library source or leave as a documented prerequisite. Never synthesize.
- `infra/` — CDK stacks are platform-team-owned (`swagger-api.ts` header comment says the real API stack lives in a separate repo `...-API-CDK...`). Generator scaffolds nothing here beyond placeholders.
- Backend integration flow (Authenticate call, SHA256 concatenation order, DynamoDB token cache, Secrets Manager ARNs, proxy URLs, Dynatrace) — **business/security logic**. Emit clearly-marked STUB sections + env-var reads; a human completes them.
- `build.sh`, `buildspec.yml`, `controller.json` — org CI/CD conventions. **CONFIG**: copy from a template repo choice made by the user.

## Naming rule (no-assumption principle)

The humans abbreviated schema filenames (`listMortgageStatement` → `listMtgStmtSchema.json`). Abbreviations are not derivable, so the generator uses the **full operationId** (`listMortgageStatementSchema.json`) — deterministic, collision-free, no guessing. Same rule everywhere: any name not literally present in the swagger is derived by a fixed documented transform of `operationId`, never by abbreviation heuristics.

## Swagger 2.0 confirmation

The production swagger embedded in `swagger-api.ts` is `"swagger": "2.0"` with `host`, `basePath`, `schemes`, `definitions` — validating the version-lock requirement end to end. The generator additionally must support emitting the API-Gateway extensions (`x-amazon-apigateway-integration`, `x-amazon-apigateway-request-validator`, `security/api_key`) as an optional pass-through layer, driven by CONFIG (account/region/lambda names), not invention.

## Generator input contract (updated)

```
swagger.json (2.0, version-locked)          -> drives schemas, handlers, starters, tests, envelopes
+ CONFIG (asked via VS Code inputs):        serviceName, env-var prefix, sanitize additions,
                                            shared-library source path, CI template choice
+ NCP rules (already extracted):            extra field constraints overlay on body schemas
= service/lambda-functions/** (generated + stubs) ; infra/ untouched placeholder
```
