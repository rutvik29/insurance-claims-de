import { assertVersionLock, VersionLockViolationError } from './src/generators/versionLock.ts';
import { envPathVar, kebab, samplePayload } from './src/generators/naming.ts';
import { readSwaggerForCodegen, dereference } from './src/generators/swaggerReader.ts';
import * as fs from 'fs';

const assert = (c: boolean, m: string) => { if (!c) { console.error('FAIL: ' + m); process.exit(1); } console.log('PASS: ' + m); };

// version lock
assert((() => { try { assertVersionLock({ swagger: '2.0' }); return true; } catch { return false; } })(), 'accepts swagger 2.0');
for (const bad of [{ openapi: '3.0.3' }, { swagger: '3.0' }, { swagger: '2.0', openapi: '3.1.0' }, {}]) {
  let threw = false; try { assertVersionLock(bad as any); } catch (e) { threw = e instanceof VersionLockViolationError; }
  assert(threw, 'rejects ' + JSON.stringify(bad));
}

// naming
assert(envPathVar('listMortgageStatement') === 'LISTMORTGAGESTATEMENT_PATH', 'envPathVar full operationId');
assert(kebab('retrieveMortgageStmt') === 'retrieve-mortgage-stmt', 'kebab transform');

// swagger reader on the fixture
const doc = JSON.parse(fs.readFileSync('test/fixtures/statement-api.swagger.json', 'utf-8'));
const model = readSwaggerForCodegen(doc);
assert(model.operations.length === 2, '2 operations read');
assert(model.operations[0].operationId === 'listStatement', 'exact operationId');
assert(JSON.stringify(model.operations[0].bodySchema) === JSON.stringify(doc.definitions.listRequest), 'body schema byte-derived');
assert(model.operations[0].headers.filter(h => h.required).map(h => h.name).join(',') === 'x-request-id,x-api-key', 'required headers');
assert(model.operations[0].statusCodes.join(',') === '200,400,500', 'status codes');
const deref = dereference({ $ref: '#/definitions/listResponse' }, doc.definitions);
assert(!JSON.stringify(deref).includes('$ref'), 'nested deref complete');
assert(JSON.stringify(samplePayload(doc.definitions.streamRequest)) === '{"encryptedKey":"test","operationName":"test","accountNumber":"test"}', 'sample payload deterministic');
let circThrew = false; try { dereference({ $ref: '#/definitions/a' }, { a: { $ref: '#/definitions/b' }, b: { $ref: '#/definitions/a' } }); } catch { circThrew = true; }
assert(circThrew, 'circular refs rejected');
let v3Threw = false; try { readSwaggerForCodegen({ openapi: '3.0.3', paths: {} } as any); } catch { v3Threw = true; }
assert(v3Threw, 'reader refuses OpenAPI 3.x');
console.log('ALL CODEGEN SMOKE TESTS PASSED');
