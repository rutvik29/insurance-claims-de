# SDLC-Banking-Assistant

End-to-end VS Code extension for a core-banking DevEx team: **WSDL/XSD + NCP rules → version-locked Swagger 2.0 → Lambda service repo**, driven by the user's GitHub Copilot subscription via the native `vscode.lm` API. No external LLM APIs, no LangChain, no local models.

## Usage — sidebar, chat, or commands

**Endpoints sidebar (Activity Bar → "SDLC Banking"):** the visual way to approve endpoints. "Load WSDL into Endpoints View" parses a WSDL and lists every operation; click a row to set its REST path + method (same approval, just persistent and visible instead of a sequence of pop-ups). Once every row shows the approved checkmark, "Generate from Approved Endpoints" (toolbar ▶) runs Swagger-only or end-to-end generation. A results panel opens afterward summarizing what was written — swagger path, the endpoint table (flagging anything still on a placeholder), and every generated file.

**Copilot Chat:** type `@sdlc build a swagger based on the WSDL and NCP doc` (or `/swagger`, `/repo`, `/endToEnd`). The participant walks you through file pickers and endpoint approval, then opens the same results panel.

**Command palette:**

- **SDLC: Generate Swagger 2.0 from WSDL + NCP** — agentic (2–3 Copilot requests)
- **SDLC: Generate Service Repo from swagger.json** — fully deterministic (0 Copilot requests)
- **SDLC: End-to-End (WSDL + NCP → Swagger 2.0 → Service Repo)** — both steps in one run

All three paths (sidebar, chat, command palette) funnel into the same `runSwaggerFlow`/`runRepoFlow`/`runEndToEndFlow` logic in `src/extension.ts` — the sidebar just supplies endpoint approvals up front instead of asking mid-flow.

## Endpoint approval — Copilot never chooses endpoints

Before any Copilot request, the WSDL is parsed locally and you are asked for the REST path + method of **every operation** (default `/placeholder/<operation>` if the endpoint isn't approved yet), either via the Endpoints sidebar or sequential prompts — both produce the identical `ApprovedOperation[]` shape. Three gates guarantee the swagger is correct:

1. The agent loop **rejects** any `generateSwagger` call whose mapping deviates from your approved endpoints — the tool never executes.
2. The tool itself Zod-validates the mapping, renders through the version-locked template, and validates with swagger-parser.
3. After generation, the swagger.json on disk is re-read and verified: version `2.0`, every approved endpoint present with the exact operationId, no extra operations, exact basePath.

## How it works

Copilot is a **router, not an author**. The agent loop (`src/orchestrator/swaggerAgent.ts`) gives the model four deterministic tools:

1. `sdlc-banking_readWsdlSchema` — `fast-xml-parser` extracts operations/fields byte-for-byte.
2. `sdlc-banking_queryNcpRules` — regex registry extracts headers/constraints/error codes (mammoth for .docx).
3. `sdlc-banking_generateSwagger` — the model submits a small Zod-validated **mapping JSON** (paths + methods only); the tool re-parses the sources and renders `swagger.json` through `src/templates/swagger/skeleton.hbs`.
4. `sdlc-banking_generateArtifacts` — renders the full service repo from swagger.json via `src/generators/repoGenerator.ts` + `src/templates/service/*.hbs`. Layout follows GENERATION_SPEC.md (derived from the real human-built repo): Lambda handlers in `index.js` (no Express — API Gateway routes), standalone JSON schemas dereferenced from swagger definitions, starters with `TODO(BUSINESS-LOGIC)` stubs, mocha/chai/c8 tests, `.env.example` placeholder inventory, `infra/` untouched.

**Version lock:** `"swagger": "2.0"` exists only as a literal in the template. `assertVersionLock()` plus `@apidevtools/swagger-parser` validation gate every generation. There is no OpenAPI 3.x code path anywhere.

**Anti-hallucination gates:** mappings referencing operations not present in the WSDL are rejected; unknown XSD types throw instead of being guessed; all names are copied exactly from source.

**Frontend:** `src/views/endpointTreeProvider.ts` (the Endpoints sidebar — a `vscode.TreeDataProvider`, zero extra state beyond what `collectEndpointApprovals()` already modeled) and `src/views/summaryPanel.ts` (a read-only, script-free `vscode.WebviewPanel` results report). Neither talks to Copilot or writes files — they're presentation only, over the same deterministic data every other entry point uses.

## Getting started

```bash
npm install
npm test           # jest: parsers + generator (no VS Code host needed)
npm run compile    # tsc strict + copies .hbs templates into dist/
npm run package     # @vscode/vsce package -> sdlc-banking-assistant-0.1.0.vsix
```

Then F5 (Extension Development Host) → command palette → **SDLC: Generate Swagger 2.0 from WSDL + NCP**, or open the **SDLC Banking** icon in the Activity Bar for the Endpoints view. Requires GitHub Copilot installed and signed in (VS Code ≥ 1.95).

Try it with the fixtures: `test/fixtures/AccountService.wsdl` + `test/fixtures/ncp-rules.txt`.

`smoke.mts` / `smoke2.mts` are zero-dependency sanity checks runnable before `npm install` (they only touch modules with no npm deps — `vscode`-coupled files like `extension.ts` and the views aren't reachable this way, same as `swaggerAgent.ts`/`endpointApproval.ts` today):
`node --experimental-strip-types smoke.mts && node --experimental-strip-types smoke2.mts`

## Copilot quota

A full generation costs 2–3 chat requests. Parsing and rendering are 100% local. The loop is capped at 8 iterations and never runs outside an explicit command.

## Next milestones (see PLAN.md, Phase 7)

Swagger generation and Lambda service-repo generation (this README's §"How it works", steps 3–4) are done. What's left is Phase 7 hardening: Copilot rate-limit backoff/coalescing, content-hash caching of parsed WSDL/NCP so template-only tweaks cost zero Copilot requests, pre-flight token budgeting for large WSDLs, a local audit manifest per generation, and packaging (`contributes.walkthroughs`, CHANGELOG, `vsce` publish).
