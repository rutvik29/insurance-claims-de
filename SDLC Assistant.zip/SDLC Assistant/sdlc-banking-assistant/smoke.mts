import { extractNcpRules } from './src/parsers/ncpExtractor.ts';
import { mapXsdType, isXsdPrimitive, UnknownXsdTypeError } from './src/parsers/xsdTypeMapper.ts';
import * as fs from 'fs';

const text = fs.readFileSync('test/fixtures/ncp-rules.txt', 'utf-8');
const rules = extractNcpRules(text);
const assert = (cond: boolean, msg: string) => { if (!cond) { console.error('FAIL: ' + msg); process.exit(1); } console.log('PASS: ' + msg); };

assert(rules.headers.length === 3, '3 headers extracted');
assert(rules.headers[0].name === 'X-Channel-Id' && rules.headers[0].required, 'X-Channel-Id mandatory');
assert(rules.headers[2].required === false, 'X-Session-Token optional');
assert(rules.fieldRules.length === 3, '3 field rules');
assert(rules.fieldRules[1].value === '^[0-9]{6,12}$', 'pattern rule exact');
assert(rules.errorCodes.map(e => e.code).join(',') === 'E1001,E1002,E1003', 'error codes exact');
assert(mapXsdType('decimal').type === 'number' && mapXsdType('decimal').format === 'double', 'decimal->number/double');
assert(mapXsdType('date').format === 'date' && mapXsdType('int').format === 'int32', 'date/int mapping');
assert(isXsdPrimitive('string') && !isXsdPrimitive('Transaction'), 'primitive detection');
try { mapXsdType('madeUpType'); console.error('FAIL: unknown type did not throw'); process.exit(1); }
catch (e) { assert(e instanceof UnknownXsdTypeError, 'unknown XSD type throws (no guessing)'); }
console.log('ALL SMOKE TESTS PASSED');
