import * as fs from 'fs';
import * as path from 'path';
import { readSwaggerForCodegen, dereference, SwaggerReadError } from '../../src/generators/swaggerReader';

const doc = JSON.parse(
  fs.readFileSync(path.join(__dirname, '..', 'fixtures', 'statement-api.swagger.json'), 'utf-8'),
);

describe('swaggerReader (deterministic codegen model)', () => {
  const model = readSwaggerForCodegen(doc);

  it('extracts operations keyed by exact operationId', () => {
    expect(model.operations.map((o) => o.operationId)).toEqual(['listStatement', 'retrieveStatement']);
    expect(model.operations[0]!.path).toBe('/list/get');
    expect(model.operations[0]!.method).toBe('post');
  });

  it('dereferences the body schema into a standalone schema (byte-derived)', () => {
    const body = model.operations[0]!.bodySchema!;
    expect(body).toEqual(doc.definitions.listRequest); // flat definition: deref is identity
    expect(body.required).toEqual(['account']);
    expect(body.properties.account.description).toBe('Account number');
  });

  it('captures header parameters with required flags', () => {
    const headers = model.operations[0]!.headers;
    expect(headers).toEqual([
      { name: 'x-request-id', required: true },
      { name: 'x-api-key', required: true },
      { name: 'x-client-id', required: false },
    ]);
  });

  it('captures declared status codes only', () => {
    expect(model.operations[0]!.statusCodes).toEqual(['200', '400', '500']);
  });

  it('resolves nested refs recursively', () => {
    const resolved = dereference({ $ref: '#/definitions/listResponse' }, doc.definitions);
    expect(resolved.properties.result.properties.code.type).toBe('string');
    expect(resolved.properties.statements.items.properties.key.type).toBe('string');
    expect(JSON.stringify(resolved)).not.toContain('$ref');
  });

  it('rejects unsupported and dangling refs loudly', () => {
    expect(() => dereference({ $ref: 'external.json#/Foo' }, doc.definitions)).toThrow(SwaggerReadError);
    expect(() => dereference({ $ref: '#/definitions/nope' }, doc.definitions)).toThrow(SwaggerReadError);
  });

  it('rejects circular definitions instead of looping', () => {
    const circular = { a: { $ref: '#/definitions/b' }, b: { $ref: '#/definitions/a' } };
    expect(() => dereference({ $ref: '#/definitions/a' }, circular)).toThrow(/Circular/);
  });

  it('VERSION LOCK: refuses OpenAPI 3.x documents', () => {
    expect(() => readSwaggerForCodegen({ openapi: '3.0.3', paths: {} })).toThrow(/VERSION LOCK/);
  });

  it('requires an operationId on every operation', () => {
    const bad = JSON.parse(JSON.stringify(doc));
    delete bad.paths['/list/get'].post.operationId;
    expect(() => readSwaggerForCodegen(bad)).toThrow(/operationId/);
  });
});
