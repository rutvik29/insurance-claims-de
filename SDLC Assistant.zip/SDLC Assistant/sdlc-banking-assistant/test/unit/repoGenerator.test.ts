import * as fs from 'fs';
import * as path from 'path';
import { generateRepoFiles, envPathVar, kebab, samplePayload, RepoGenError } from '../../src/generators/repoGenerator';

const doc = JSON.parse(
  fs.readFileSync(path.join(__dirname, '..', 'fixtures', 'statement-api.swagger.json'), 'utf-8'),
);
const config = { serviceName: 'Statement-Service', envPrefix: 'STATEMENTSERVICE' };

describe('name transforms (fixed, no abbreviation heuristics)', () => {
  it('envPathVar uses the FULL operationId uppercased', () => {
    expect(envPathVar('listMortgageStatement')).toBe('LISTMORTGAGESTATEMENT_PATH');
    expect(envPathVar('listStatement')).toBe('LISTSTATEMENT_PATH');
  });

  it('kebab derives URL-safe placeholder segments', () => {
    expect(kebab('retrieveStatement')).toBe('retrieve-statement');
  });

  it('samplePayload builds a minimal valid payload from required fields only', () => {
    expect(samplePayload(doc.definitions.streamRequest)).toEqual({
      encryptedKey: 'test',
      operationName: 'test',
      accountNumber: 'test',
    });
  });
});

describe('repoGenerator (spec-compliant output)', () => {
  const files = generateRepoFiles(doc, config);
  const get = (p: string): string => {
    const content = files.get(p);
    if (content === undefined) throw new Error(`missing generated file: ${p}`);
    return content;
  };

  it('emits the exact repo layout from GENERATION_SPEC.md', () => {
    const paths = [...files.keys()];
    expect(paths).toEqual(
      expect.arrayContaining([
        'README.md',
        '.env.example',
        '.gitignore',
        'swagger.json',
        'infra/.gitkeep',
        'service/lambda-functions/index.js',
        'service/lambda-functions/properties.js',
        'service/lambda-functions/package.json',
        'service/lambda-functions/resources/validator/schemaValidator.js',
        'service/lambda-functions/resources/schema/listStatementSchema.json',
        'service/lambda-functions/resources/schema/retrieveStatementSchema.json',
        'service/lambda-functions/service/listStatementServiceStarter.js',
        'service/lambda-functions/service/retrieveStatementServiceStarter.js',
        'service/lambda-functions/service/mapping/mapResponse.js',
        'service/lambda-functions/service/sub/headerMapper.js',
        'service/lambda-functions/common/logger/framework.js',
        'service/lambda-functions/test/listStatementSchema.test.js',
        'service/lambda-functions/test/listStatementStarter.test.js',
        'service/lambda-functions/test/headerMapper.test.js',
      ]),
    );
  });

  it('infra stays an empty placeholder', () => {
    expect(get('infra/.gitkeep')).toBe('');
    expect([...files.keys()].filter((p) => p.startsWith('infra/'))).toEqual(['infra/.gitkeep']);
  });

  it('schema files are byte-derived from the swagger definitions', () => {
    expect(JSON.parse(get('service/lambda-functions/resources/schema/listStatementSchema.json'))).toEqual(
      doc.definitions.listRequest,
    );
    expect(
      JSON.parse(get('service/lambda-functions/resources/schema/retrieveStatementSchema.json')),
    ).toEqual(doc.definitions.streamRequest);
  });

  it('index.js exports one <operationId>Lambda per operation via framework.execute', () => {
    const index = get('service/lambda-functions/index.js');
    expect(index).toContain('exports.listStatementLambda');
    expect(index).toContain('exports.retrieveStatementLambda');
    expect(index).toContain('framework.execute(event, context, callback, listStatementService, options)');
    expect(index).toContain('sanitizeArray: properties.sanitizeList');
    expect(index).not.toContain('express'); // no Express anywhere — API Gateway routes
  });

  it('starters enforce the placeholder strategy with env vars', () => {
    const starter = get('service/lambda-functions/service/listStatementServiceStarter.js');
    expect(starter).toContain('process.env.STATEMENTSERVICE_HOST');
    expect(starter).toContain('process.env.LISTSTATEMENT_PATH || "/placeholder/list-statement"');
    expect(starter).toContain('TODO(BUSINESS-LOGIC)');
    expect(starter).toContain('schemaValidator(inputreq, schema)');
  });

  it('.env.example documents every placeholder with its source operation', () => {
    const env = get('.env.example');
    expect(env).toContain('STATEMENTSERVICE_HOST=');
    expect(env).toContain('LISTSTATEMENT_PATH=/placeholder/list-statement');
    expect(env).toContain('RETRIEVESTATEMENT_PATH=/placeholder/retrieve-statement');
    expect(env).toContain('POST /list/get');
  });

  it('generated package.json is mocha/c8 (not jest) with ajv runtime dep', () => {
    const pkg = JSON.parse(get('service/lambda-functions/package.json'));
    expect(pkg.scripts.test).toContain('mocha');
    expect(pkg.scripts.test).toContain('c8');
    expect(pkg.dependencies.ajv).toBeDefined();
    expect(pkg.devDependencies.jest).toBeUndefined();
  });

  it('properties.js sanitizeList is seeded from swagger body property names', () => {
    const props = get('service/lambda-functions/properties.js');
    for (const key of ['account', 'accountNumber', 'encryptedKey', 'operationName', 'startDate']) {
      expect(props).toContain(`"${key}"`);
    }
  });

  it('framework stub is clearly marked as a replaceable STUB', () => {
    expect(get('service/lambda-functions/common/logger/framework.js')).toContain('STUB');
  });

  it('schema tests cover missing-required-field cases per field', () => {
    const test = get('service/lambda-functions/test/listStatementSchema.test.js');
    expect(test).toContain("missing required field 'account'");
    expect(test).toContain('{"account":"test"}');
  });

  it('embeds the swagger verbatim and is idempotent', () => {
    expect(JSON.parse(get('swagger.json'))).toEqual(doc);
    const second = generateRepoFiles(doc, config);
    expect([...second.entries()]).toEqual([...files.entries()]);
  });

  it('VERSION LOCK: refuses non-2.0 documents', () => {
    expect(() => generateRepoFiles({ openapi: '3.1.0', paths: {} }, config)).toThrow(/VERSION LOCK/);
  });

  it('rejects invalid envPrefix instead of normalizing silently', () => {
    expect(() => generateRepoFiles(doc, { serviceName: 'x', envPrefix: 'bad-prefix' })).toThrow(
      RepoGenError,
    );
  });
});
