import {
  approvalGateError,
  verifySwaggerDoc,
  SwaggerVerificationError,
  ApprovalContext,
} from '../../src/orchestrator/approvalGate';

const ctx: ApprovalContext = {
  outputUri: '/repo/swagger.json',
  basePath: '/account/v1',
  approvedOperations: [
    { operationName: 'AccountInquiry', path: '/account-inquiry', method: 'post' },
    { operationName: 'MiniStatement', path: '/mini-statement', method: 'post' },
  ],
};

const goodInput = {
  wsdlUri: 'a.wsdl',
  ncpUri: 'n.txt',
  outputUri: '/repo/swagger.json',
  mapping: {
    info: { title: 'T', version: '1.0.0' },
    basePath: '/account/v1',
    operations: [
      { operationName: 'AccountInquiry', path: '/account-inquiry', method: 'post' },
      { operationName: 'MiniStatement', path: '/mini-statement', method: 'post' },
    ],
  },
};

describe('approvalGateError — the model cannot deviate from user-approved endpoints', () => {
  it('accepts an exactly-matching mapping', () => {
    expect(approvalGateError(goodInput, ctx)).toBeUndefined();
  });

  it('rejects a changed path', () => {
    const bad = JSON.parse(JSON.stringify(goodInput));
    bad.mapping.operations[0].path = '/model-invented-path';
    expect(approvalGateError(bad, ctx)).toContain('must be exactly post /account-inquiry');
  });

  it('rejects a changed method', () => {
    const bad = JSON.parse(JSON.stringify(goodInput));
    bad.mapping.operations[1].method = 'get';
    expect(approvalGateError(bad, ctx)).toContain('post /mini-statement');
  });

  it('rejects invented operations', () => {
    const bad = JSON.parse(JSON.stringify(goodInput));
    bad.mapping.operations[0].operationName = 'FundsTransfer';
    expect(approvalGateError(bad, ctx)).toContain('not in the approved list');
  });

  it('rejects dropped operations', () => {
    const bad = JSON.parse(JSON.stringify(goodInput));
    bad.mapping.operations.pop();
    expect(approvalGateError(bad, ctx)).toContain('exactly 2 operations');
  });

  it('rejects a changed basePath or outputUri', () => {
    expect(approvalGateError({ ...goodInput, outputUri: '/elsewhere.json' }, ctx)).toContain('outputUri');
    const bad = JSON.parse(JSON.stringify(goodInput));
    bad.mapping.basePath = '/other';
    expect(approvalGateError(bad, ctx)).toContain('basePath');
  });
});

describe('verifySwaggerDoc — final on-disk verification', () => {
  const goodDoc = {
    swagger: '2.0',
    basePath: '/account/v1',
    paths: {
      '/account-inquiry': { post: { operationId: 'AccountInquiry' } },
      '/mini-statement': { post: { operationId: 'MiniStatement' } },
    },
  };

  it('accepts a document matching the approvals exactly', () => {
    expect(() => verifySwaggerDoc(goodDoc, ctx)).not.toThrow();
  });

  it('rejects a missing approved endpoint', () => {
    const bad = JSON.parse(JSON.stringify(goodDoc));
    delete bad.paths['/mini-statement'];
    expect(() => verifySwaggerDoc(bad, ctx)).toThrow(SwaggerVerificationError);
  });

  it('rejects extra undeclared endpoints', () => {
    const bad = JSON.parse(JSON.stringify(goodDoc));
    bad.paths['/extra'] = { post: { operationId: 'Extra' } };
    expect(() => verifySwaggerDoc(bad, ctx)).toThrow(/declares 3 operations/);
  });

  it('rejects a wrong operationId at an approved endpoint', () => {
    const bad = JSON.parse(JSON.stringify(goodDoc));
    bad.paths['/account-inquiry'].post.operationId = 'Renamed';
    expect(() => verifySwaggerDoc(bad, ctx)).toThrow(/Renamed/);
  });

  it('rejects wrong version or basePath', () => {
    expect(() => verifySwaggerDoc({ ...goodDoc, swagger: '3.0' }, ctx)).toThrow(/VERSION LOCK/);
    expect(() => verifySwaggerDoc({ ...goodDoc, basePath: '/x' }, ctx)).toThrow(/basePath/);
  });
});
