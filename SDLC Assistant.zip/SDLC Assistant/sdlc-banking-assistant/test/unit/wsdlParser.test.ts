import * as fs from 'fs';
import * as path from 'path';
import { parseWsdl } from '../../src/parsers/wsdlParser';

const wsdlXml = fs.readFileSync(path.join(__dirname, '..', 'fixtures', 'AccountService.wsdl'), 'utf-8');

describe('wsdlParser (deterministic, byte-exact)', () => {
  const parsed = parseWsdl(wsdlXml);

  it('extracts the service name and namespace exactly', () => {
    expect(parsed.serviceName).toBe('AccountService');
    expect(parsed.targetNamespace).toBe('http://bank.example.com/account/v1');
  });

  it('extracts both operations with exact names', () => {
    expect(parsed.operations.map((o) => o.name)).toEqual(['AccountInquiry', 'MiniStatement']);
  });

  it('preserves field names byte-for-byte (no re-casing)', () => {
    const inquiry = parsed.operations[0]!;
    expect(inquiry.input.elementName).toBe('AccountInquiryRequest');
    expect(inquiry.input.fields.map((f) => f.name)).toEqual([
      'accountNumber',
      'branchCode',
      'inquiryType',
    ]);
  });

  it('extracts XSD facet constraints', () => {
    const accountNumber = parsed.operations[0]!.input.fields[0]!;
    expect(accountNumber.constraints.maxLength).toBe(12);
    expect(accountNumber.constraints.pattern).toBe('[0-9]{6,12}');
    const inquiryType = parsed.operations[0]!.input.fields[2]!;
    expect(inquiryType.constraints.enum).toEqual(['BALANCE', 'FULL']);
  });

  it('marks optionality from minOccurs', () => {
    const branchCode = parsed.operations[0]!.input.fields[1]!;
    expect(branchCode.required).toBe(false);
    const accountNumber = parsed.operations[0]!.input.fields[0]!;
    expect(accountNumber.required).toBe(true);
  });

  it('maps XSD primitives to Swagger types deterministically', () => {
    const balance = parsed.operations[0]!.output.fields.find((f) => f.name === 'availableBalance')!;
    expect(balance.swaggerType).toBe('number');
    expect(balance.swaggerFormat).toBe('double');
    const maxEntries = parsed.operations[1]!.input.fields.find((f) => f.name === 'maxEntries')!;
    expect(maxEntries.swaggerType).toBe('integer');
    expect(maxEntries.swaggerFormat).toBe('int32');
  });

  it('resolves named complex types and unbounded arrays', () => {
    const transactions = parsed.operations[1]!.output.fields.find((f) => f.name === 'transactions')!;
    expect(transactions.isArray).toBe(true);
    expect(transactions.complexRef).toBe('Transaction');
    expect(parsed.types['Transaction']!.map((f) => f.name)).toEqual([
      'transactionId',
      'postingDate',
      'amount',
      'narrative',
    ]);
  });

  it('rejects non-WSDL XML loudly', () => {
    expect(() => parseWsdl('<foo/>')).toThrow(/missing <wsdl:definitions>/);
  });
});
