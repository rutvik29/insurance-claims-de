import * as fs from 'fs';
import * as path from 'path';
import { extractNcpRules } from '../../src/parsers/ncpExtractor';

const ncpText = fs.readFileSync(path.join(__dirname, '..', 'fixtures', 'ncp-rules.txt'), 'utf-8');

describe('ncpExtractor (regex registry, zero tokens)', () => {
  const rules = extractNcpRules(ncpText);

  it('extracts headers with exact names and mandatory flags', () => {
    expect(rules.headers).toEqual([
      {
        name: 'X-Channel-Id',
        required: true,
        description: 'Identifies the originating channel (MOBILE, WEB, BRANCH)',
      },
      {
        name: 'X-Request-Id',
        required: true,
        description: 'Unique correlation identifier for end-to-end tracing',
      },
      {
        name: 'X-Session-Token',
        required: false,
        description: 'Session token for authenticated channels',
      },
    ]);
  });

  it('extracts field constraints', () => {
    expect(rules.fieldRules).toEqual([
      { field: 'accountNumber', rule: 'MAXLENGTH', value: '12' },
      { field: 'accountNumber', rule: 'PATTERN', value: '^[0-9]{6,12}$' },
      { field: 'currency', rule: 'ENUM', value: 'USD,EUR,GBP,INR' },
    ]);
  });

  it('extracts error codes', () => {
    expect(rules.errorCodes.map((e) => e.code)).toEqual(['E1001', 'E1002', 'E1003']);
  });

  it('returns empty results (not garbage) for unrelated text', () => {
    const empty = extractNcpRules('lorem ipsum dolor sit amet');
    expect(empty).toEqual({ headers: [], fieldRules: [], errorCodes: [] });
  });
});
