/**
 * Deterministic repo generator: version-locked swagger.json -> service repo.
 *
 * Emits the layout evidenced by the reference repo (see GENERATION_SPEC.md):
 *   <repo>/
 *   ├── README.md, .gitignore, .env.example, swagger.json
 *   ├── infra/.gitkeep                          (placeholder — platform-owned)
 *   └── service/lambda-functions/
 *       ├── index.js                            (one exports.<opId>Lambda per operation)
 *       ├── properties.js, package.json         (mocha/chai/c8, ajv)
 *       ├── resources/schema/<opId>Schema.json  (dereferenced body definitions)
 *       ├── resources/validator/schemaValidator.js
 *       ├── service/<opId>ServiceStarter.js     (validation + TODO(BUSINESS-LOGIC) stubs)
 *       ├── service/mapping/mapResponse.js
 *       ├── service/sub/headerMapper.js
 *       ├── common/logger/framework.js          (STUB — replace with internal library)
 *       └── test/*.test.js                      (mocha)
 *
 * NO-ASSUMPTION rules enforced here:
 *  - Names derive from operationId by fixed transforms only (no abbreviation guessing).
 *  - Schemas are byte-derived from swagger definitions (dereference, no edits).
 *  - Business logic beyond schema validation is emitted as explicit TODO stubs.
 *  - Every route/host is an env-var placeholder documented in .env.example.
 */

import * as fs from 'fs';
import * as path from 'path';
import Handlebars from 'handlebars';
import { readSwaggerForCodegen, SwaggerCodegenOperation } from './swaggerReader';
import { assertVersionLock } from './versionLock';
export { envPathVar, kebab, samplePayload } from './naming';
import { envPathVar, kebab, samplePayload } from './naming';

/* eslint-disable @typescript-eslint/no-explicit-any */
type JsonObject = Record<string, any>;

export interface RepoGenConfig {
  /** Human service name, e.g. "Mortgage-loan-statement". */
  serviceName: string;
  /** Env-var prefix for the backend host, e.g. "MORTGAGELOANSTATEMENT". */
  envPrefix: string;
}

export class RepoGenError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RepoGenError';
  }
}

// ---------------------------------------------------------------------------
// Template engine
// ---------------------------------------------------------------------------

const TEMPLATE_DIR = path.join(__dirname, '..', 'templates', 'service');

function createEngine(): typeof Handlebars {
  const handlebars = Handlebars.create();
  handlebars.registerHelper('json', (value: unknown) => JSON.stringify(value));
  return handlebars as typeof Handlebars;
}

function render(engine: typeof Handlebars, templateFile: string, context: JsonObject): string {
  const source = fs.readFileSync(path.join(TEMPLATE_DIR, templateFile), 'utf-8');
  return engine.compile(source, { noEscape: true, strict: false })(context);
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

function operationContext(op: SwaggerCodegenOperation, config: RepoGenConfig): JsonObject {
  const payload = op.bodySchema ? samplePayload(op.bodySchema) : {};
  const requiredFields: string[] =
    op.bodySchema && Array.isArray(op.bodySchema.required) ? op.bodySchema.required : [];
  return {
    operationId: op.operationId,
    path: op.path,
    methodUpper: op.method.toUpperCase(),
    kebabId: kebab(op.operationId),
    envPathVar: envPathVar(op.operationId),
    hasBodySchema: op.bodySchema !== undefined,
    samplePayloadJson: JSON.stringify(payload),
    requiredFields,
    hasRequiredFields: requiredFields.length > 0,
    serviceName: config.serviceName,
    envPrefix: config.envPrefix,
  };
}

/**
 * Generates the full repo as a map of relative POSIX paths -> file contents.
 * Pure function of (swagger doc, config): idempotent and unit-testable.
 */
export function generateRepoFiles(swaggerDoc: JsonObject, config: RepoGenConfig): Map<string, string> {
  assertVersionLock(swaggerDoc);
  if (!/^[A-Z][A-Z0-9]*$/.test(config.envPrefix)) {
    throw new RepoGenError(
      `envPrefix "${config.envPrefix}" must be UPPERCASE alphanumeric (e.g. MORTGAGELOANSTATEMENT).`,
    );
  }
  const model = readSwaggerForCodegen(swaggerDoc);
  const engine = createEngine();
  const files = new Map<string, string>();
  const base = 'service/lambda-functions';

  const ops = model.operations.map((op) => operationContext(op, config));
  const sanitizeSeed = [
    ...new Set(
      model.operations.flatMap((op) =>
        op.bodySchema?.properties ? Object.keys(op.bodySchema.properties as JsonObject) : [],
      ),
    ),
  ].sort();

  const shared: JsonObject = {
    serviceName: config.serviceName,
    envPrefix: config.envPrefix,
    swaggerTitle: model.title,
    packageName: config.serviceName.replace(/[^A-Za-z0-9-]/g, '-'),
    operations: ops,
    sanitizeSeed,
  };

  // --- root ---------------------------------------------------------------
  files.set('README.md', render(engine, 'repoReadme.md.hbs', shared));
  files.set('.env.example', render(engine, 'envExample.hbs', shared));
  files.set('.gitignore', 'node_modules/\ncoverage/\n.env\n');
  files.set('swagger.json', JSON.stringify(swaggerDoc, null, 2) + '\n');
  files.set('infra/.gitkeep', ''); // placeholder — platform team owns infra

  // --- service/lambda-functions --------------------------------------------
  files.set(`${base}/index.js`, render(engine, 'index.js.hbs', shared));
  files.set(`${base}/properties.js`, render(engine, 'properties.js.hbs', shared));
  files.set(`${base}/package.json`, render(engine, 'package.json.hbs', shared));
  files.set(
    `${base}/resources/validator/schemaValidator.js`,
    render(engine, 'schemaValidator.js.hbs', shared),
  );
  files.set(
    `${base}/service/mapping/mapResponse.js`,
    render(engine, 'mapResponse.js.hbs', { ...shared, hasErrorResponseDefinition: true }),
  );
  files.set(`${base}/service/sub/headerMapper.js`, render(engine, 'headerMapper.js.hbs', shared));
  files.set(`${base}/common/logger/framework.js`, render(engine, 'framework.js.hbs', shared));
  files.set(`${base}/test/headerMapper.test.js`, render(engine, 'headerMapperTest.js.hbs', shared));

  // --- per operation --------------------------------------------------------
  for (let i = 0; i < model.operations.length; i++) {
    const op = model.operations[i]!;
    const ctx = ops[i]!;
    if (op.bodySchema) {
      // Byte-derived from the swagger definition — full operationId, no abbreviations.
      files.set(
        `${base}/resources/schema/${op.operationId}Schema.json`,
        JSON.stringify(op.bodySchema, null, 2) + '\n',
      );
      files.set(`${base}/test/${op.operationId}Schema.test.js`, render(engine, 'schemaTest.js.hbs', ctx));
    }
    files.set(
      `${base}/service/${op.operationId}ServiceStarter.js`,
      render(engine, 'serviceStarter.js.hbs', ctx),
    );
    files.set(`${base}/test/${op.operationId}Starter.test.js`, render(engine, 'starterTest.js.hbs', ctx));
  }

  return files;
}
