/**
 * Deterministic Swagger 2.0 reader for code generation.
 *
 * Reads a (version-locked) swagger.json into a codegen model:
 *  - one entry per operation (operationId is mandatory — evidence: the real
 *    repo keys every artifact off operationId)
 *  - the body parameter's schema fully dereferenced against #/definitions
 *    (evidence: resources/schema/<op>Schema.json in the human-built repo is
 *    exactly the dereferenced body definition)
 *  - header parameters and declared status codes
 *
 * No LLM involvement. Unknown $refs and missing operationIds fail loudly.
 */

import { assertVersionLock } from './versionLock';

/* eslint-disable @typescript-eslint/no-explicit-any */
type JsonObject = Record<string, any>;

export interface SwaggerHeaderParam {
  name: string;
  required: boolean;
}

export interface SwaggerCodegenOperation {
  operationId: string;
  path: string;
  method: string;
  /** Fully dereferenced standalone JSON Schema for the body, if a body param exists. */
  bodySchema?: JsonObject;
  headers: SwaggerHeaderParam[];
  statusCodes: string[];
  consumes: string[];
  produces: string[];
}

export interface SwaggerCodegenModel {
  title: string;
  version: string;
  basePath: string;
  operations: SwaggerCodegenOperation[];
}

export class SwaggerReadError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SwaggerReadError';
  }
}

const HTTP_METHODS = ['get', 'post', 'put', 'delete', 'patch', 'head', 'options'] as const;

/**
 * Recursively resolves #/definitions/X refs into an inline standalone schema.
 * Only local definition refs are supported — anything else fails loudly.
 */
export function dereference(schema: JsonObject, definitions: JsonObject, seen: string[] = []): JsonObject {
  if (typeof schema.$ref === 'string') {
    const ref: string = schema.$ref;
    const match = /^#\/definitions\/(.+)$/.exec(ref);
    if (!match || match[1] === undefined) {
      throw new SwaggerReadError(`Unsupported $ref "${ref}" — only #/definitions/* refs are supported.`);
    }
    const name = match[1];
    if (seen.includes(name)) {
      throw new SwaggerReadError(
        `Circular $ref detected: ${[...seen, name].join(' -> ')}. Standalone schemas cannot be circular.`,
      );
    }
    const target = definitions[name];
    if (!target) {
      throw new SwaggerReadError(`$ref "${ref}" does not resolve to a definition.`);
    }
    return dereference(target, definitions, [...seen, name]);
  }

  const out: JsonObject = {};
  for (const [key, value] of Object.entries(schema)) {
    if (Array.isArray(value)) {
      out[key] = value.map((item) =>
        item && typeof item === 'object' ? dereference(item as JsonObject, definitions, seen) : item,
      );
    } else if (value && typeof value === 'object') {
      out[key] = dereference(value as JsonObject, definitions, seen);
    } else {
      out[key] = value;
    }
  }
  return out;
}

export function readSwaggerForCodegen(doc: JsonObject): SwaggerCodegenModel {
  assertVersionLock(doc);

  const definitions: JsonObject = doc.definitions ?? {};
  const operations: SwaggerCodegenOperation[] = [];

  for (const [pathKey, pathItem] of Object.entries<JsonObject>(doc.paths ?? {})) {
    for (const method of HTTP_METHODS) {
      const op: JsonObject | undefined = (pathItem as JsonObject)[method];
      if (!op) {
        continue;
      }
      const operationId: string | undefined = op.operationId;
      if (!operationId || !/^[A-Za-z][A-Za-z0-9]*$/.test(operationId)) {
        throw new SwaggerReadError(
          `Operation ${method.toUpperCase()} ${pathKey} needs a valid operationId (identifier-safe) — every generated artifact is keyed off it.`,
        );
      }

      const params: JsonObject[] = Array.isArray(op.parameters) ? op.parameters : [];
      const headers: SwaggerHeaderParam[] = params
        .filter((p) => p.in === 'header')
        .map((p) => ({ name: String(p.name), required: p.required === true }));

      const bodyParam = params.find((p) => p.in === 'body');
      let bodySchema: JsonObject | undefined;
      if (bodyParam) {
        if (!bodyParam.schema) {
          throw new SwaggerReadError(`Body parameter of ${operationId} has no schema.`);
        }
        bodySchema = dereference(bodyParam.schema, definitions);
      }

      operations.push({
        operationId,
        path: pathKey,
        method,
        ...(bodySchema !== undefined ? { bodySchema } : {}),
        headers,
        statusCodes: Object.keys(op.responses ?? {}),
        consumes: op.consumes ?? doc.consumes ?? ['application/json'],
        produces: op.produces ?? doc.produces ?? ['application/json'],
      });
    }
  }

  if (operations.length === 0) {
    throw new SwaggerReadError('Swagger document declares no operations.');
  }

  return {
    title: String(doc.info?.title ?? ''),
    version: String(doc.info?.version ?? ''),
    basePath: String(doc.basePath ?? '/'),
    operations,
  };
}
