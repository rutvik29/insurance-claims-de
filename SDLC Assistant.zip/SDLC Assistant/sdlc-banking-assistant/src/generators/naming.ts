/**
 * Fixed, documented name transforms for code generation — dependency-free.
 * NO abbreviation heuristics: every derived name is a deterministic function
 * of the exact operationId (see GENERATION_SPEC.md, "Naming rule").
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
type JsonObject = Record<string, any>;

/** listMortgageStatement -> LISTMORTGAGESTATEMENT_PATH. */
export const envPathVar = (operationId: string): string => `${operationId.toUpperCase()}_PATH`;

/** listMortgageStatement -> list-mortgage-statement. */
export const kebab = (operationId: string): string =>
  operationId.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();

/** Deterministic minimal valid payload from a schema's required fields. */
export function samplePayload(schema: JsonObject): JsonObject {
  const payload: JsonObject = {};
  const required: string[] = Array.isArray(schema.required) ? schema.required : [];
  const properties: JsonObject = schema.properties ?? {};
  for (const field of required) {
    const prop: JsonObject = properties[field] ?? {};
    switch (prop.type) {
      case 'integer':
        payload[field] = 1;
        break;
      case 'number':
        payload[field] = 1.0;
        break;
      case 'boolean':
        payload[field] = true;
        break;
      case 'array':
        payload[field] = [];
        break;
      case 'object':
        payload[field] = samplePayload(prop);
        break;
      default:
        payload[field] = prop.enum?.[0] ?? 'test';
    }
  }
  return payload;
}
