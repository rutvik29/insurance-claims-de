/**
 * Deterministic Swagger 2.0 generator.
 *
 * VERSION LOCK: `"swagger": "2.0"` exists ONLY as a literal inside
 * templates/swagger/skeleton.hbs. No code path in this repository can set,
 * change, or upgrade the version. assertVersionLock() re-verifies the rendered
 * document and fails hard on anything else. There is NO OpenAPI 3.x conversion
 * anywhere in this codebase, by design.
 *
 * Inputs:
 *  - ParsedWsdl  (from wsdlParser — byte-exact names/types/constraints)
 *  - NcpRules    (from ncpExtractor — headers, field rules, error codes)
 *  - SwaggerMapping (the ONLY LLM-produced artifact, already Zod-validated)
 */

import * as fs from 'fs';
import * as path from 'path';
import Handlebars from 'handlebars';
import SwaggerParser from '@apidevtools/swagger-parser';
import { ParsedWsdl, WsdlField, WsdlOperation } from '../parsers/wsdlParser';
import { NcpRules } from '../parsers/ncpExtractor';
import { SwaggerMapping } from '../schemas/swaggerMapping';

/* eslint-disable @typescript-eslint/no-explicit-any */
type JsonObject = Record<string, any>;

export { assertVersionLock, VersionLockViolationError } from './versionLock';
import { assertVersionLock } from './versionLock';

export class MappingValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'MappingValidationError';
  }
}

// ---------------------------------------------------------------------------
// Property construction (pure, deterministic)
// ---------------------------------------------------------------------------

function propertyForField(field: WsdlField, ncp: NcpRules): JsonObject {
  let prop: JsonObject;

  if (field.complexRef) {
    prop = { $ref: `#/definitions/${field.complexRef}` };
  } else {
    prop = { type: field.swaggerType };
    if (field.swaggerFormat) {
      prop.format = field.swaggerFormat;
    }
    if (field.constraints.maxLength !== undefined) {
      prop.maxLength = field.constraints.maxLength;
    }
    if (field.constraints.minLength !== undefined) {
      prop.minLength = field.constraints.minLength;
    }
    if (field.constraints.pattern !== undefined) {
      prop.pattern = field.constraints.pattern;
    }
    if (field.constraints.enum !== undefined) {
      prop.enum = field.constraints.enum;
    }
    // NCP field rules overlay XSD constraints (NCP is the business source of truth).
    for (const rule of ncp.fieldRules) {
      if (rule.field !== field.name) {
        continue;
      }
      switch (rule.rule) {
        case 'MAXLENGTH':
          prop.maxLength = Number(rule.value);
          break;
        case 'MINLENGTH':
          prop.minLength = Number(rule.value);
          break;
        case 'PATTERN':
          prop.pattern = rule.value;
          break;
        case 'ENUM':
          prop.enum = rule.value.split(',').map((v) => v.trim());
          break;
      }
    }
  }

  if (field.isArray) {
    return { type: 'array', items: prop };
  }
  return prop;
}

function definitionForFields(fields: WsdlField[], ncp: NcpRules): JsonObject {
  const properties: JsonObject = {};
  const required: string[] = [];
  for (const field of fields) {
    properties[field.name] = propertyForField(field, ncp);
    if (field.required) {
      required.push(field.name);
    }
  }
  const definition: JsonObject = { type: 'object', properties };
  if (required.length > 0) {
    definition.required = required;
  }
  return definition;
}

// ---------------------------------------------------------------------------
// Path construction
// ---------------------------------------------------------------------------

function headerParameters(ncp: NcpRules): JsonObject[] {
  // Emit every NCP-documented header, mandatory or optional, with its real
  // `required` flag. Dropping optional headers would discard information the
  // NCP doc already gave us — the no-assumption principle cuts both ways.
  return ncp.headers.map((h) => ({
    name: h.name,
    in: 'header',
    required: h.required,
    type: 'string',
    description: h.description,
  }));
}

/**
 * Standard non-200 status catalogue for generated operations, evidenced in
 * GENERATION_SPEC.md (swagger-api.ts `responses` blocks): 200,400,401,403,
 * 404,415,429,500,502,504 — every non-200 references the errorResponse
 * definition. Descriptions here are generic HTTP semantics, not copied from
 * any specific source swagger.
 */
const STANDARD_ERROR_STATUSES: ReadonlyArray<[code: string, description: string]> = [
  ['401', 'Unauthorized'],
  ['403', 'Forbidden'],
  ['404', 'Not Found'],
  ['415', 'Unsupported Media Type'],
  ['429', 'Too Many Requests'],
  ['500', 'Internal Server Error'],
  ['502', 'Bad Gateway'],
  ['504', 'Gateway Timeout'],
];

/**
 * Generic RFC-7807-style error envelope (type/title/status/detail/instance/
 * resultDetails) matching the shape GENERATION_SPEC.md documents and that
 * service/mapping/mapResponse.js.hbs already emits at runtime. Field
 * descriptions are written generically here, not copied from any reference doc.
 */
function errorResponseDefinition(): JsonObject {
  return {
    type: 'object',
    properties: {
      type: { type: 'string', format: 'uri', description: 'URI identifying the problem type.' },
      title: { type: 'string', description: 'Short, human-readable summary of the problem type.' },
      status: {
        type: 'integer',
        format: 'int32',
        description: 'HTTP status code for this occurrence of the problem.',
      },
      detail: { type: 'string', description: 'Human-readable explanation specific to this occurrence.' },
      instance: {
        type: 'string',
        format: 'uri',
        description: 'URI identifying this specific occurrence of the problem.',
      },
      resultDetails: {
        type: 'array',
        items: { type: 'object' },
        description: 'Additional structured error details.',
      },
    },
  };
}

function operationObject(
  wsdlOp: WsdlOperation,
  method: string,
  summary: string | undefined,
  ncp: NcpRules,
): JsonObject {
  const parameters: JsonObject[] = [...headerParameters(ncp)];

  if (method === 'get') {
    for (const field of wsdlOp.input.fields) {
      if (field.complexRef || field.isArray) {
        throw new MappingValidationError(
          `Operation "${wsdlOp.name}" cannot be mapped to GET: input field "${field.name}" is not a primitive. Use POST instead.`,
        );
      }
      const param: JsonObject = {
        name: field.name,
        in: 'query',
        required: field.required,
        type: field.swaggerType,
      };
      if (field.swaggerFormat) {
        param.format = field.swaggerFormat;
      }
      parameters.push(param);
    }
  } else {
    parameters.push({
      name: 'body',
      in: 'body',
      required: true,
      schema: { $ref: `#/definitions/${wsdlOp.input.elementName}` },
    });
  }

  const errorCatalogue =
    ncp.errorCodes.length > 0
      ? ` Possible business error codes: ${ncp.errorCodes.map((e) => `${e.code} (${e.description})`).join('; ')}.`
      : '';

  const responses: JsonObject = {
    '200': {
      description: 'Successful response',
      schema: { $ref: `#/definitions/${wsdlOp.output.elementName}` },
    },
    '400': {
      description: `Bad Request — validation error.${errorCatalogue}`,
      schema: { $ref: '#/definitions/errorResponse' },
    },
  };
  for (const [code, description] of STANDARD_ERROR_STATUSES) {
    responses[code] = { description, schema: { $ref: '#/definitions/errorResponse' } };
  }

  return {
    operationId: wsdlOp.name, // byte-exact WSDL operation name
    summary: summary ?? `Generated from WSDL operation ${wsdlOp.name}`,
    parameters,
    responses,
  };
}

// ---------------------------------------------------------------------------
// Template rendering (the ONLY place the version string exists)
// ---------------------------------------------------------------------------

const TEMPLATE_PATH = path.join(__dirname, '..', 'templates', 'swagger', 'skeleton.hbs');

function renderSkeleton(context: JsonObject): string {
  const handlebars = Handlebars.create();
  handlebars.registerHelper('json', (value: unknown) => JSON.stringify(value));
  const source = fs.readFileSync(TEMPLATE_PATH, 'utf-8');
  const template = handlebars.compile(source, { noEscape: true, strict: true });
  return template(context);
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export interface GeneratedSwagger {
  /** The parsed, validated document. */
  doc: JsonObject;
  /** Pretty-printed JSON ready to write to swagger.json. */
  json: string;
}

export async function generateSwagger(
  wsdl: ParsedWsdl,
  ncp: NcpRules,
  mapping: SwaggerMapping,
): Promise<GeneratedSwagger> {
  // 1. Anti-hallucination gate: every mapped operation must exist in the WSDL.
  const wsdlOpsByName = new Map(wsdl.operations.map((op) => [op.name, op]));
  const unknown = mapping.operations
    .map((m) => m.operationName)
    .filter((name) => !wsdlOpsByName.has(name));
  if (unknown.length > 0) {
    throw new MappingValidationError(
      `Mapping references operation(s) not present in the WSDL: ${unknown.join(', ')}. ` +
        `Valid operations are: ${[...wsdlOpsByName.keys()].join(', ')}.`,
    );
  }
  const duplicates = mapping.operations
    .map((m) => `${m.method.toUpperCase()} ${m.path}`)
    .filter((key, i, arr) => arr.indexOf(key) !== i);
  if (duplicates.length > 0) {
    throw new MappingValidationError(`Duplicate method+path in mapping: ${duplicates.join(', ')}.`);
  }

  // 2. Paths — driven by the validated mapping, populated from parsed WSDL data.
  const paths: JsonObject = {};
  for (const m of mapping.operations) {
    const wsdlOp = wsdlOpsByName.get(m.operationName) as WsdlOperation;
    paths[m.path] = paths[m.path] ?? {};
    paths[m.path][m.method] = operationObject(wsdlOp, m.method, m.summary, ncp);
  }

  // 3. Definitions — message elements + referenced named complex types.
  const definitions: JsonObject = {};
  for (const m of mapping.operations) {
    const wsdlOp = wsdlOpsByName.get(m.operationName) as WsdlOperation;
    definitions[wsdlOp.input.elementName] = definitionForFields(wsdlOp.input.fields, ncp);
    definitions[wsdlOp.output.elementName] = definitionForFields(wsdlOp.output.fields, ncp);
  }
  for (const [typeName, fields] of Object.entries(wsdl.types)) {
    definitions[typeName] = definitionForFields(fields, ncp);
  }
  // Every non-200 response above references this; never overwrite a same-named
  // definition the WSDL itself already produced.
  definitions.errorResponse = definitions.errorResponse ?? errorResponseDefinition();

  // 4. Render through the version-locked template.
  const rendered = renderSkeleton({
    info: mapping.info,
    basePath: mapping.basePath,
    paths,
    definitions,
  });
  const doc: JsonObject = JSON.parse(rendered);

  // 5. Hard gates: version lock + full semantic validation (all local, zero tokens).
  assertVersionLock(doc);
  await SwaggerParser.validate(JSON.parse(JSON.stringify(doc))); // validate a clone; it mutates
  assertVersionLock(doc);

  return { doc, json: JSON.stringify(doc, null, 2) + '\n' };
}
