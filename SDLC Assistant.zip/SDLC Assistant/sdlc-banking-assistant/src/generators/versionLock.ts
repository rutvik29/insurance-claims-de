/**
 * VERSION LOCK — dependency-free, shared by every module that touches a
 * Swagger document. The document must declare exactly swagger "2.0" and no
 * openapi key. No upgrade/conversion path exists anywhere in this codebase.
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
type JsonObject = Record<string, any>;

export class VersionLockViolationError extends Error {
  constructor(found: unknown) {
    super(
      `VERSION LOCK VIOLATION: document is not Swagger 2.0 (found: ${JSON.stringify(found)}). Aborted.`,
    );
    this.name = 'VersionLockViolationError';
  }
}

export function assertVersionLock(doc: JsonObject): void {
  if (doc.swagger !== '2.0' || 'openapi' in doc) {
    throw new VersionLockViolationError(doc.swagger ?? doc.openapi);
  }
}
