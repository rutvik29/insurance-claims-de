/**
 * Endpoint approval gate — dependency-free so it is fully unit-testable.
 *
 * Endpoints are a HUMAN decision. These functions enforce that:
 *  - approvalGateError()   rejects a generateSwagger tool input whose mapping
 *    deviates from the approved endpoints (checked BEFORE the tool executes)
 *  - verifySwaggerDoc()    re-verifies the final swagger document on disk
 */

import { assertVersionLock } from '../generators/versionLock';

/* eslint-disable @typescript-eslint/no-explicit-any */

export interface ApprovedOperation {
  operationName: string;
  path: string;
  method: 'get' | 'post' | 'put' | 'delete' | 'patch';
}

export interface ApprovalContext {
  outputUri: string;
  basePath: string;
  approvedOperations: ApprovedOperation[];
}

export class SwaggerVerificationError extends Error {
  constructor(message: string) {
    super(`Post-generation verification failed: ${message}`);
    this.name = 'SwaggerVerificationError';
  }
}

/** Returns an error string if the tool input deviates from the approvals; undefined if OK. */
export function approvalGateError(input: any, ctx: ApprovalContext): string | undefined {
  const ops: any[] = input?.mapping?.operations ?? [];
  const approvedByName = new Map(ctx.approvedOperations.map((o) => [o.operationName, o]));

  if (input?.outputUri !== ctx.outputUri) {
    return `outputUri must be exactly "${ctx.outputUri}".`;
  }
  if (input?.mapping?.basePath !== ctx.basePath) {
    return `basePath must be exactly "${ctx.basePath}" (user-approved).`;
  }
  if (ops.length !== ctx.approvedOperations.length) {
    return `mapping must contain exactly ${ctx.approvedOperations.length} operations (one per approved endpoint).`;
  }
  for (const op of ops) {
    const approved = approvedByName.get(op?.operationName);
    if (!approved) {
      return `operationName "${op?.operationName}" is not in the approved list: ${[...approvedByName.keys()].join(', ')}.`;
    }
    if (op.path !== approved.path || op.method !== approved.method) {
      return `Endpoint for "${approved.operationName}" must be exactly ${approved.method} ${approved.path} (user-approved), got ${op.method} ${op.path}.`;
    }
  }
  return undefined;
}

/** Verifies the final swagger document: version lock + approved endpoints, nothing extra. */
export function verifySwaggerDoc(doc: any, ctx: ApprovalContext): void {
  assertVersionLock(doc);
  const paths: Record<string, any> = doc.paths ?? {};
  for (const approved of ctx.approvedOperations) {
    const opObject = paths[approved.path]?.[approved.method];
    if (!opObject) {
      throw new SwaggerVerificationError(
        `approved endpoint ${approved.method} ${approved.path} is missing from the generated swagger.`,
      );
    }
    if (opObject.operationId !== approved.operationName) {
      throw new SwaggerVerificationError(
        `operationId at ${approved.method} ${approved.path} is "${opObject.operationId}", expected "${approved.operationName}".`,
      );
    }
  }
  const declaredCount = Object.values(paths).reduce(
    (count: number, item: any) => count + Object.keys(item as object).length,
    0,
  );
  if (declaredCount !== ctx.approvedOperations.length) {
    throw new SwaggerVerificationError(
      `swagger declares ${declaredCount} operations but ${ctx.approvedOperations.length} were approved.`,
    );
  }
  if (doc.basePath !== ctx.basePath) {
    throw new SwaggerVerificationError(`basePath is "${doc.basePath}", expected "${ctx.basePath}".`);
  }
}
