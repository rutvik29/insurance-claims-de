/**
 * Endpoint approval — endpoints are a HUMAN decision, never the model's.
 *
 * Before any Copilot request, the WSDL is parsed locally and the user is asked
 * for the REST path + HTTP method of every operation. The agent loop then
 * REJECTS any generateSwagger call whose mapping deviates from these approvals.
 */

import * as vscode from 'vscode';
import { parseWsdl } from '../parsers/wsdlParser';
import { readFileText } from '../utils/fileIo';
import { kebab } from '../generators/naming';

export interface ApprovedOperation {
  /** Exact WSDL operation name. */
  operationName: string;
  /** User-approved REST path (starts with /). */
  path: string;
  /** User-approved HTTP method. */
  method: 'get' | 'post' | 'put' | 'delete' | 'patch';
}

const METHODS: ApprovedOperation['method'][] = ['post', 'get', 'put', 'delete', 'patch'];

const validatePath = (value: string): string | undefined =>
  /^\/[A-Za-z0-9\-._~/{}]*$/.test(value)
    ? undefined
    : 'Path must start with / and contain only URL-safe characters';

/**
 * Parses the WSDL deterministically and asks the user to approve an endpoint
 * for every operation. Returns undefined if the user cancels.
 */
export async function collectEndpointApprovals(
  wsdlUri: string,
): Promise<ApprovedOperation[] | undefined> {
  const wsdl = parseWsdl(await readFileText(wsdlUri));
  const approvals: ApprovedOperation[] = [];

  for (let i = 0; i < wsdl.operations.length; i++) {
    const op = wsdl.operations[i]!;
    const path = await vscode.window.showInputBox({
      title: `Endpoint ${i + 1}/${wsdl.operations.length} — REST path for WSDL operation "${op.name}"`,
      prompt:
        'This value is used EXACTLY as entered. If the endpoint is not approved yet, keep the /placeholder/ default — the generated code reads it from an env var.',
      value: `/placeholder/${kebab(op.name)}`,
      ignoreFocusOut: true,
      validateInput: validatePath,
    });
    if (path === undefined) {
      return undefined; // user cancelled
    }

    const methodPick = await vscode.window.showQuickPick(
      METHODS.map((m) => ({
        label: m.toUpperCase(),
        description: m === 'post' ? 'default for banking operations' : undefined,
        method: m,
      })),
      {
        title: `HTTP method for "${op.name}" (${path})`,
        ignoreFocusOut: true,
      },
    );
    if (!methodPick) {
      return undefined;
    }

    approvals.push({ operationName: op.name, path, method: methodPick.method });
  }

  return approvals;
}
