/**
 * The agentic loop: WSDL + NCP -> version-locked Swagger 2.0.
 *
 * Copilot (via vscode.lm) is a ROUTER only. Three hard gates guarantee the
 * output is correct:
 *  1. Endpoints are USER-APPROVED before any Copilot request; a generateSwagger
 *     call whose mapping deviates is rejected in this loop without executing.
 *  2. The tool itself re-parses sources, Zod-validates the mapping, renders the
 *     version-locked template, and validates with swagger-parser.
 *  3. After the loop, the written swagger.json is re-read and verified again
 *     (version lock + every approved endpoint present, nothing extra).
 */

import * as vscode from 'vscode';
import { readFileText } from '../utils/fileIo';
import { ApprovedOperation } from './endpointApproval';
import { approvalGateError, verifySwaggerDoc, SwaggerVerificationError } from './approvalGate';

export { SwaggerVerificationError };

const TOOL_READ_WSDL = 'sdlc-banking_readWsdlSchema';
const TOOL_QUERY_NCP = 'sdlc-banking_queryNcpRules';
const TOOL_GENERATE = 'sdlc-banking_generateSwagger';
const MAX_ITERATIONS = 8;

export interface SwaggerAgentRequest {
  wsdlUri: string;
  ncpUri: string;
  outputUri: string;
  apiTitle: string;
  apiVersion: string;
  basePath: string;
  /** User-approved endpoints — the model must use these EXACTLY. */
  approvedOperations: ApprovedOperation[];
}

export class CopilotUnavailableError extends Error {
  constructor() {
    super(
      'No Copilot language model available. Ensure GitHub Copilot is installed, signed in, and enabled by your organization.',
    );
    this.name = 'CopilotUnavailableError';
  }
}

function buildPrompt(request: SwaggerAgentRequest): string {
  const endpointTable = request.approvedOperations
    .map((o) => `  - operationName: "${o.operationName}" -> ${o.method} ${o.path}`)
    .join('\n');
  return [
    'You are a deterministic routing agent inside a VS Code extension for a core-banking team.',
    'Workflow (strict order):',
    `1) call readWsdl on the WSDL file; 2) call queryNcp on the NCP file;`,
    `3) call generateSwagger EXACTLY ONCE with mapping = { info: { title: "${request.apiTitle}", version: "${request.apiVersion}" }, basePath: "${request.basePath}", operations: [...] }.`,
    'The user has APPROVED these endpoints. Use them EXACTLY — any deviation is rejected:',
    endpointTable,
    'Rules: operationName values are copied EXACTLY from the list above — never rename, re-case, or invent operations.',
    'You may add a short "summary" per operation based on the WSDL/NCP tool output. The Swagger version is',
    'locked to 2.0 by the tool. Never write Swagger content yourself; only submit the mapping.',
    `Files — WSDL: ${request.wsdlUri} | NCP: ${request.ncpUri} | output: ${request.outputUri}`,
    'After generateSwagger returns status ok, reply with a one-line summary and stop.',
  ].join('\n');
}

/** Re-reads the written swagger.json and verifies it against the approvals. */
export async function verifyGeneratedSwagger(request: SwaggerAgentRequest): Promise<void> {
  let doc: unknown;
  try {
    doc = JSON.parse(await readFileText(request.outputUri));
  } catch {
    throw new SwaggerVerificationError(
      `swagger.json was not written to ${request.outputUri} — the agent finished without generating.`,
    );
  }
  verifySwaggerDoc(doc, request);
}

async function selectCopilotModel(): Promise<vscode.LanguageModelChat> {
  const models = await vscode.lm.selectChatModels({ vendor: 'copilot' });
  const model = models[0];
  if (!model) {
    throw new CopilotUnavailableError();
  }
  return model;
}

function extractToolResultText(result: vscode.LanguageModelToolResult): string {
  return result.content
    .filter((part): part is vscode.LanguageModelTextPart => part instanceof vscode.LanguageModelTextPart)
    .map((part) => part.value)
    .join('');
}

export async function runSwaggerAgent(
  request: SwaggerAgentRequest,
  progress: vscode.Progress<{ message?: string }>,
  token: vscode.CancellationToken,
  modelOverride?: vscode.LanguageModelChat,
): Promise<string> {
  if (request.approvedOperations.length === 0) {
    throw new Error('No approved endpoints — endpoint approval must run before the agent.');
  }
  const model = modelOverride ?? (await selectCopilotModel());

  const ourTools = vscode.lm.tools.filter((t) =>
    [TOOL_READ_WSDL, TOOL_QUERY_NCP, TOOL_GENERATE].includes(t.name),
  );
  if (ourTools.length !== 3) {
    throw new Error(
      `Expected 3 registered SDLC tools, found ${ourTools.length}. Check languageModelTools registration.`,
    );
  }

  const messages: vscode.LanguageModelChatMessage[] = [
    vscode.LanguageModelChatMessage.User(buildPrompt(request)),
  ];

  let summary = '';
  for (let iteration = 0; iteration < MAX_ITERATIONS; iteration++) {
    if (token.isCancellationRequested) {
      throw new vscode.CancellationError();
    }
    progress.report({ message: `Copilot round ${iteration + 1}…` });

    const response = await model.sendRequest(
      messages,
      {
        tools: ourTools,
        toolMode: vscode.LanguageModelChatToolMode.Auto,
        justification: 'Generate a version-locked Swagger 2.0 definition from legacy banking specs.',
      },
      token,
    );

    const textParts: string[] = [];
    const toolCalls: vscode.LanguageModelToolCallPart[] = [];
    for await (const part of response.stream) {
      if (part instanceof vscode.LanguageModelTextPart) {
        textParts.push(part.value);
      } else if (part instanceof vscode.LanguageModelToolCallPart) {
        toolCalls.push(part);
      }
    }

    if (toolCalls.length === 0) {
      summary = textParts.join('').trim();
      break;
    }

    messages.push(
      vscode.LanguageModelChatMessage.Assistant([
        ...textParts.map((t) => new vscode.LanguageModelTextPart(t)),
        ...toolCalls,
      ]),
    );

    const resultParts: vscode.LanguageModelToolResultPart[] = [];
    for (const call of toolCalls) {
      // HARD GATE: endpoint approvals are enforced BEFORE the tool executes.
      if (call.name === TOOL_GENERATE) {
        const gateError = approvalGateError(call.input, request);
        if (gateError) {
          progress.report({ message: 'Rejected non-approved endpoint mapping…' });
          resultParts.push(
            new vscode.LanguageModelToolResultPart(call.callId, [
              new vscode.LanguageModelTextPart(JSON.stringify({ error: `REJECTED: ${gateError}` })),
            ]),
          );
          continue;
        }
      }
      progress.report({ message: `Running ${call.name}…` });
      const result = await vscode.lm.invokeTool(
        call.name,
        { input: call.input, toolInvocationToken: undefined },
        token,
      );
      resultParts.push(
        new vscode.LanguageModelToolResultPart(call.callId, [
          new vscode.LanguageModelTextPart(extractToolResultText(result)),
        ]),
      );
    }
    messages.push(vscode.LanguageModelChatMessage.User(resultParts));

    if (iteration === MAX_ITERATIONS - 1) {
      throw new Error(
        `Agent exceeded ${MAX_ITERATIONS} iterations without completing. Aborted to protect your Copilot quota.`,
      );
    }
  }

  // FINAL GATE: verify the actual file on disk against the approvals.
  progress.report({ message: 'Verifying generated swagger against approved endpoints…' });
  await verifyGeneratedSwagger(request);

  return summary || 'swagger.json generated and verified against approved endpoints.';
}
