/**
 * LM Tool: sdlc-banking_readWsdlSchema
 * Deterministic WSDL parsing exposed to Copilot. Returns a token-lean JSON
 * summary — exact operation names, element names, and field name/type pairs.
 */

import * as vscode from 'vscode';
import { z } from 'zod';
import { ReadWsdlInput, ReadWsdlInputSchema } from '../schemas/toolContracts';
import { parseWsdl, ParsedWsdl } from '../parsers/wsdlParser';
import { readFileText } from '../utils/fileIo';

/** Token-lean summary sent to the model (full parse stays local). */
export function summarizeWsdl(wsdl: ParsedWsdl): object {
  return {
    serviceName: wsdl.serviceName,
    operations: wsdl.operations.map((op) => ({
      name: op.name,
      inputElement: op.input.elementName,
      inputFields: op.input.fields.map(
        (f) => `${f.name}:${f.complexRef ?? f.swaggerType}${f.isArray ? '[]' : ''}${f.required ? '' : '?'}`,
      ),
      outputElement: op.output.elementName,
      outputFields: op.output.fields.map(
        (f) => `${f.name}:${f.complexRef ?? f.swaggerType}${f.isArray ? '[]' : ''}${f.required ? '' : '?'}`,
      ),
    })),
  };
}

export class ReadWsdlSchemaTool implements vscode.LanguageModelTool<ReadWsdlInput> {
  prepareInvocation(
    options: vscode.LanguageModelToolInvocationPrepareOptions<ReadWsdlInput>,
  ): vscode.PreparedToolInvocation {
    return { invocationMessage: `Parsing WSDL schema: ${options.input.fileUri}` };
  }

  async invoke(
    options: vscode.LanguageModelToolInvocationOptions<ReadWsdlInput>,
    _token: vscode.CancellationToken,
  ): Promise<vscode.LanguageModelToolResult> {
    try {
      const input = ReadWsdlInputSchema.parse(options.input);
      const xml = await readFileText(input.fileUri);
      const parsed = parseWsdl(xml);
      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(JSON.stringify(summarizeWsdl(parsed))),
      ]);
    } catch (error) {
      const message =
        error instanceof z.ZodError
          ? `Invalid input: ${error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ')}`
          : `WSDL parse failed: ${error instanceof Error ? error.message : String(error)}`;
      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(JSON.stringify({ error: message })),
      ]);
    }
  }
}
