/**
 * LM Tool: sdlc-banking_queryNcpRules
 * Regex-based rule extraction from NCP .txt/.docx. Only the matched rules
 * (typically < 1 KB) are returned to the model — never the whole document.
 */

import * as vscode from 'vscode';
import { z } from 'zod';
import { QueryNcpInput, QueryNcpInputSchema } from '../schemas/toolContracts';
import { extractNcpRules } from '../parsers/ncpExtractor';
import { extractDocxText } from '../parsers/docxReader';
import { readFileBytes } from '../utils/fileIo';

export async function loadNcpText(fileUri: string): Promise<string> {
  const bytes = await readFileBytes(fileUri);
  if (fileUri.toLowerCase().endsWith('.docx')) {
    return extractDocxText(Buffer.from(bytes));
  }
  return Buffer.from(bytes).toString('utf-8');
}

export class QueryNcpRulesTool implements vscode.LanguageModelTool<QueryNcpInput> {
  prepareInvocation(
    options: vscode.LanguageModelToolInvocationPrepareOptions<QueryNcpInput>,
  ): vscode.PreparedToolInvocation {
    return { invocationMessage: `Extracting NCP business rules: ${options.input.fileUri}` };
  }

  async invoke(
    options: vscode.LanguageModelToolInvocationOptions<QueryNcpInput>,
    _token: vscode.CancellationToken,
  ): Promise<vscode.LanguageModelToolResult> {
    try {
      const input = QueryNcpInputSchema.parse(options.input);
      const text = await loadNcpText(input.fileUri);
      const rules = extractNcpRules(text);
      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(JSON.stringify(rules)),
      ]);
    } catch (error) {
      const message =
        error instanceof z.ZodError
          ? `Invalid input: ${error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ')}`
          : `NCP extraction failed: ${error instanceof Error ? error.message : String(error)}`;
      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(JSON.stringify({ error: message })),
      ]);
    }
  }
}
