/**
 * LM Tool: sdlc-banking_generateSwagger
 * THE tool that writes swagger.json. The model supplies only the mapping;
 * the document itself is rendered deterministically from re-parsed sources
 * through the version-locked template, then validated before writing.
 */

import * as vscode from 'vscode';
import { z } from 'zod';
import { GenerateSwaggerInput, GenerateSwaggerInputSchema } from '../schemas/toolContracts';
import { parseWsdl } from '../parsers/wsdlParser';
import { extractNcpRules } from '../parsers/ncpExtractor';
import { generateSwagger } from '../generators/swaggerGenerator';
import { readFileText, writeFileText } from '../utils/fileIo';
import { loadNcpText } from './queryNcpRules';

export class GenerateSwaggerTool implements vscode.LanguageModelTool<GenerateSwaggerInput> {
  prepareInvocation(
    options: vscode.LanguageModelToolInvocationPrepareOptions<GenerateSwaggerInput>,
  ): vscode.PreparedToolInvocation {
    return {
      invocationMessage: 'Rendering version-locked Swagger 2.0 document',
      confirmationMessages: {
        title: 'Generate swagger.json',
        message: new vscode.MarkdownString(
          `Write **swagger.json** (Swagger **2.0**, version-locked) to \`${options.input.outputUri}\` with ${options.input.mapping?.operations?.length ?? 0} operation(s)?`,
        ),
      },
    };
  }

  async invoke(
    options: vscode.LanguageModelToolInvocationOptions<GenerateSwaggerInput>,
    _token: vscode.CancellationToken,
  ): Promise<vscode.LanguageModelToolResult> {
    try {
      const input = GenerateSwaggerInputSchema.parse(options.input);

      // Re-parse from source files — the model's summaries are never trusted as data.
      const wsdl = parseWsdl(await readFileText(input.wsdlUri));
      const ncp = extractNcpRules(await loadNcpText(input.ncpUri));

      const { json } = await generateSwagger(wsdl, ncp, input.mapping);
      await writeFileText(input.outputUri, json);

      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(
          JSON.stringify({
            status: 'ok',
            written: input.outputUri,
            swaggerVersion: '2.0',
            operations: input.mapping.operations.map((o) => `${o.method.toUpperCase()} ${o.path}`),
          }),
        ),
      ]);
    } catch (error) {
      // Structured error back to the model: exactly one corrective retry is
      // allowed by the orchestrator; the message contains only what failed.
      const message =
        error instanceof z.ZodError
          ? `Mapping rejected: ${error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ')}`
          : `Generation failed: ${error instanceof Error ? error.message : String(error)}`;
      return new vscode.LanguageModelToolResult([
        new vscode.LanguageModelTextPart(JSON.stringify({ error: message })),
      ]);
    }
  }
}
