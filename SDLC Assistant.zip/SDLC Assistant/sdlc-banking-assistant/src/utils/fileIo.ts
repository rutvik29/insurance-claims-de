/**
 * Small file helpers shared by the LM tools. Accepts either a file URI
 * ("file:///...") or a plain filesystem path — the model may pass either.
 */

import * as vscode from 'vscode';

export function toUri(fileUriOrPath: string): vscode.Uri {
  return fileUriOrPath.startsWith('file://')
    ? vscode.Uri.parse(fileUriOrPath)
    : vscode.Uri.file(fileUriOrPath);
}

export async function readFileBytes(fileUriOrPath: string): Promise<Uint8Array> {
  return vscode.workspace.fs.readFile(toUri(fileUriOrPath));
}

export async function readFileText(fileUriOrPath: string): Promise<string> {
  const bytes = await readFileBytes(fileUriOrPath);
  return Buffer.from(bytes).toString('utf-8');
}

export async function writeFileText(fileUriOrPath: string, content: string): Promise<void> {
  await vscode.workspace.fs.writeFile(toUri(fileUriOrPath), Buffer.from(content, 'utf-8'));
}
