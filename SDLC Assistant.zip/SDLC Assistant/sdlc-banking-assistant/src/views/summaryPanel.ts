/**
 * Webview results summary — shown after any generation flow completes.
 *
 * Pure presentation: every field is passed in already-computed, nothing is
 * fetched or derived here. No scripts, no external resources (enableScripts
 * stays false) — this is a read-only report, not an interactive surface.
 */

import * as vscode from 'vscode';

export interface SummaryEndpoint {
  operationName: string;
  method: string;
  path: string;
  isPlaceholder: boolean;
}

export interface SummaryData {
  title: string;
  swaggerPath?: string;
  outputDir?: string;
  endpoints: SummaryEndpoint[];
  repoFiles?: string[];
  notes: string[];
}

function esc(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderEndpointRows(endpoints: SummaryEndpoint[]): string {
  return endpoints
    .map(
      (e) => `
        <tr>
          <td>${esc(e.operationName)}</td>
          <td><code>${esc(e.method.toUpperCase())}</code></td>
          <td><code>${esc(e.path)}</code></td>
          <td>${
            e.isPlaceholder
              ? '<span class="badge warn">placeholder — needs config</span>'
              : '<span class="badge ok">approved</span>'
          }</td>
        </tr>`,
    )
    .join('');
}

function renderFileList(files: string[]): string {
  return files.map((f) => `<li><code>${esc(f)}</code></li>`).join('');
}

function renderHtml(data: SummaryData): string {
  const placeholderCount = data.endpoints.filter((e) => e.isPlaceholder).length;
  const endpointsSection = data.endpoints.length
    ? `
      <h2>Endpoints (${data.endpoints.length}${placeholderCount ? `, ${placeholderCount} still placeholder` : ''})</h2>
      <table>
        <tr><th>Operation</th><th>Method</th><th>Path</th><th>Status</th></tr>
        ${renderEndpointRows(data.endpoints)}
      </table>`
    : '';

  const filesSection = data.repoFiles?.length
    ? `<h2>Generated files (${data.repoFiles.length})</h2><ul class="files">${renderFileList(data.repoFiles)}</ul>`
    : '';

  const notesSection = data.notes.length
    ? `<h2>Notes</h2><ul>${data.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>`
    : '';

  const pathsSection = `
    <ul class="paths">
      ${data.swaggerPath ? `<li><strong>Swagger:</strong> <code>${esc(data.swaggerPath)}</code></li>` : ''}
      ${data.outputDir ? `<li><strong>Repo:</strong> <code>${esc(data.outputDir)}</code></li>` : ''}
    </ul>`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline';" />
<style>
  body {
    font-family: var(--vscode-font-family, sans-serif);
    color: var(--vscode-foreground);
    padding: 8px 28px 32px;
    line-height: 1.5;
  }
  h1 { font-size: 1.35em; margin-bottom: 4px; }
  h2 { font-size: 1.05em; margin-top: 28px; border-bottom: 1px solid var(--vscode-panel-border); padding-bottom: 4px; }
  table { border-collapse: collapse; width: 100%; margin-top: 10px; }
  th, td { text-align: left; padding: 6px 10px; border-bottom: 1px solid var(--vscode-panel-border); font-size: 0.92em; }
  th { color: var(--vscode-descriptionForeground); font-weight: 600; }
  code {
    background: var(--vscode-textCodeBlock-background, rgba(127,127,127,0.15));
    padding: 1px 6px;
    border-radius: 3px;
    font-family: var(--vscode-editor-font-family, monospace);
  }
  .badge { padding: 2px 9px; border-radius: 10px; font-size: 0.82em; white-space: nowrap; }
  .badge.ok { background: var(--vscode-testing-iconPassed, #2ea043); color: #fff; }
  .badge.warn { background: var(--vscode-editorWarning-foreground, #cca700); color: #000; }
  ul { margin: 6px 0; padding-left: 22px; }
  ul.paths { list-style: none; padding-left: 0; }
  ul.paths li { margin: 3px 0; }
  ul.files { columns: 2; max-height: 360px; overflow-y: auto; }
  ul.files li { font-size: 0.88em; break-inside: avoid; }
</style>
</head>
<body>
  <h1>${esc(data.title)}</h1>
  ${pathsSection}
  ${endpointsSection}
  ${filesSection}
  ${notesSection}
</body>
</html>`;
}

/** Opens (or reuses) the summary webview panel and renders the given data. */
export function showSummaryPanel(data: SummaryData): vscode.WebviewPanel {
  const panel = vscode.window.createWebviewPanel(
    'sdlcBankingSummary',
    data.title,
    { viewColumn: vscode.ViewColumn.Beside, preserveFocus: false },
    { enableScripts: false, retainContextWhenHidden: true },
  );
  panel.webview.html = renderHtml(data);
  return panel;
}
