/**
 * Sidebar tree view: WSDL operations -> approved REST endpoints.
 *
 * Endpoints remain a HUMAN decision (see orchestrator/endpointApproval.ts).
 * This view is a persistent, visual alternative to the sequential
 * showInputBox/showQuickPick flow — it does not change WHO approves an
 * endpoint or WHAT an approval means, only how it is collected. The
 * ApprovedOperation shape produced here is identical to collectEndpointApprovals's,
 * so both paths feed the same downstream agent/gates unchanged.
 */

import * as vscode from 'vscode';
import { parseWsdl, WsdlOperation } from '../parsers/wsdlParser';
import { readFileText } from '../utils/fileIo';
import { kebab } from '../generators/naming';
import { ApprovedOperation } from '../orchestrator/endpointApproval';

interface EndpointState {
  path: string;
  method: ApprovedOperation['method'];
  approved: boolean;
}

/** One row in the Endpoints view — one per WSDL operation. */
export class EndpointItem extends vscode.TreeItem {
  constructor(
    public readonly operationName: string,
    public readonly path: string,
    public readonly method: ApprovedOperation['method'],
    public readonly approved: boolean,
  ) {
    super(operationName, vscode.TreeItemCollapsibleState.None);
    this.description = `${method.toUpperCase()} ${path}`;
    this.contextValue = 'sdlcEndpoint';
    this.iconPath = new vscode.ThemeIcon(approved ? 'pass-filled' : 'circle-large-outline');
    this.tooltip = approved
      ? `Approved: ${method.toUpperCase()} ${path}`
      : `Not yet approved — generation will fall back to placeholder ${path} until you edit this endpoint.`;
    this.command = {
      command: 'sdlc-banking-assistant.editEndpoint',
      title: 'Edit endpoint',
      arguments: [operationName],
    };
  }
}

export class EndpointTreeProvider implements vscode.TreeDataProvider<EndpointItem> {
  private readonly _onDidChangeTreeData = new vscode.EventEmitter<void>();
  readonly onDidChangeTreeData: vscode.Event<void> = this._onDidChangeTreeData.event;

  private wsdlUri: string | undefined;
  private operations: WsdlOperation[] = [];
  private readonly state = new Map<string, EndpointState>();

  getWsdlUri(): string | undefined {
    return this.wsdlUri;
  }

  hasOperations(): boolean {
    return this.operations.length > 0;
  }

  /** Parses the WSDL deterministically (same parser the generator uses) and resets state. */
  async loadWsdl(wsdlUri: string): Promise<number> {
    const wsdl = parseWsdl(await readFileText(wsdlUri));
    this.wsdlUri = wsdlUri;
    this.operations = wsdl.operations;
    this.state.clear();
    for (const op of wsdl.operations) {
      this.state.set(op.name, { path: `/placeholder/${kebab(op.name)}`, method: 'post', approved: false });
    }
    this._onDidChangeTreeData.fire();
    return wsdl.operations.length;
  }

  getEndpoint(operationName: string): EndpointState | undefined {
    return this.state.get(operationName);
  }

  setEndpoint(operationName: string, path: string, method: ApprovedOperation['method']): void {
    if (!this.state.has(operationName)) {
      return;
    }
    this.state.set(operationName, { path, method, approved: true });
    this._onDidChangeTreeData.fire();
  }

  allApproved(): boolean {
    return this.operations.length > 0 && this.operations.every((op) => this.state.get(op.name)?.approved === true);
  }

  approvedCount(): number {
    return [...this.state.values()].filter((s) => s.approved).length;
  }

  /** Same shape collectEndpointApprovals() returns — either source feeds the agent identically. */
  getApprovals(): ApprovedOperation[] {
    return this.operations.map((op) => {
      const s = this.state.get(op.name)!;
      return { operationName: op.name, path: s.path, method: s.method };
    });
  }

  refresh(): void {
    this._onDidChangeTreeData.fire();
  }

  getTreeItem(element: EndpointItem): vscode.TreeItem {
    return element;
  }

  getChildren(): EndpointItem[] {
    return this.operations.map((op) => {
      const s = this.state.get(op.name)!;
      return new EndpointItem(op.name, s.path, s.method, s.approved);
    });
  }
}
