/**
 * SDLC-Banking-Assistant — extension entry point.
 *
 * Four deterministic LM tools, six commands, one chat participant (@sdlc),
 * one sidebar view (Endpoints), and a results summary webview.
 * Endpoints are ALWAYS asked from the user before any Copilot request and
 * enforced by a hard gate in the agent loop plus post-generation verification
 * — the sidebar view is an additional way to SUPPLY that approval, never a
 * way to bypass it: it produces the exact same ApprovedOperation[] shape as
 * the sequential input-box flow, so every downstream gate is unchanged.
 */

import * as vscode from 'vscode';
import { ReadWsdlSchemaTool } from './tools/readWsdlSchema';
import { QueryNcpRulesTool } from './tools/queryNcpRules';
import { GenerateSwaggerTool } from './tools/generateSwaggerTool';
import { GenerateArtifactsTool, writeRepoFromSwagger } from './tools/generateArtifactsTool';
import { runSwaggerAgent, CopilotUnavailableError, SwaggerAgentRequest } from './orchestrator/swaggerAgent';
import { collectEndpointApprovals, ApprovedOperation } from './orchestrator/endpointApproval';
import { EndpointTreeProvider, EndpointItem } from './views/endpointTreeProvider';
import { showSummaryPanel, SummaryEndpoint } from './views/summaryPanel';

const endpointProvider = new EndpointTreeProvider();

export function activate(context: vscode.ExtensionContext): void {
  const participant = vscode.chat.createChatParticipant('sdlc-banking-assistant.sdlc', chatHandler);
  participant.iconPath = new vscode.ThemeIcon('law');

  const endpointsView = vscode.window.createTreeView('sdlcEndpoints', {
    treeDataProvider: endpointProvider,
    showCollapseAll: false,
  });

  context.subscriptions.push(
    vscode.lm.registerTool('sdlc-banking_readWsdlSchema', new ReadWsdlSchemaTool()),
    vscode.lm.registerTool('sdlc-banking_queryNcpRules', new QueryNcpRulesTool()),
    vscode.lm.registerTool('sdlc-banking_generateSwagger', new GenerateSwaggerTool()),
    vscode.lm.registerTool('sdlc-banking_generateArtifacts', new GenerateArtifactsTool()),
    vscode.commands.registerCommand('sdlc-banking-assistant.generateSwagger', generateSwaggerCommand),
    vscode.commands.registerCommand('sdlc-banking-assistant.generateService', generateServiceCommand),
    vscode.commands.registerCommand('sdlc-banking-assistant.endToEnd', endToEndCommand),
    vscode.commands.registerCommand('sdlc-banking-assistant.loadWsdlForApproval', loadWsdlForApprovalCommand),
    vscode.commands.registerCommand('sdlc-banking-assistant.editEndpoint', editEndpointCommand),
    vscode.commands.registerCommand('sdlc-banking-assistant.refreshEndpointsView', () => endpointProvider.refresh()),
    vscode.commands.registerCommand(
      'sdlc-banking-assistant.generateFromEndpointsView',
      generateFromEndpointsViewCommand,
    ),
    endpointsView,
    participant,
  );
}

// ---------------------------------------------------------------------------
// Input helpers
// ---------------------------------------------------------------------------

async function pickFile(title: string, filters: Record<string, string[]>): Promise<string | undefined> {
  const picked = await vscode.window.showOpenDialog({ title, canSelectMany: false, filters });
  return picked?.[0]?.fsPath;
}

async function pickFolder(title: string): Promise<string | undefined> {
  const picked = await vscode.window.showOpenDialog({
    title,
    canSelectMany: false,
    canSelectFiles: false,
    canSelectFolders: true,
  });
  return picked?.[0]?.fsPath;
}

async function askText(
  title: string,
  value: string,
  validate?: (v: string) => string | undefined,
): Promise<string | undefined> {
  return vscode.window.showInputBox({ title, value, ignoreFocusOut: true, validateInput: validate });
}

const validateEnvPrefix = (v: string): string | undefined =>
  /^[A-Z][A-Z0-9]*$/.test(v) ? undefined : 'UPPERCASE alphanumeric only, e.g. MORTGAGELOANSTATEMENT';

const validateBasePath = (v: string): string | undefined =>
  /^\/[A-Za-z0-9\-._~/]*$/.test(v) ? undefined : 'basePath must start with /';

/** Endpoints already approved elsewhere (e.g. the sidebar view) — skips re-asking. */
interface SwaggerInputsPreset {
  wsdlUri: string;
  approvedOperations: ApprovedOperation[];
}

/**
 * Collects everything the swagger step needs. Order matters: the WSDL is
 * parsed locally FIRST so the user approves an endpoint per real operation
 * before a single Copilot token is spent. If `preset` is supplied (from the
 * Endpoints sidebar view), the WSDL pick + approval loop is skipped — the
 * preset's ApprovedOperation[] is the same shape collectEndpointApprovals()
 * returns, so every downstream gate behaves identically either way.
 */
async function collectSwaggerInputs(
  defaultOutputDir?: string,
  preset?: SwaggerInputsPreset,
): Promise<SwaggerAgentRequest | undefined> {
  const wsdlUri = preset?.wsdlUri ?? (await pickFile('Select the WSDL file', { 'WSDL/XSD': ['wsdl', 'xsd', 'xml'] }));
  if (!wsdlUri) return undefined;

  // Ask for endpoints — one per WSDL operation, parsed deterministically.
  const approvedOperations = preset?.approvedOperations ?? (await collectEndpointApprovals(wsdlUri));
  if (!approvedOperations) return undefined;

  const ncpUri = await pickFile('Select the NCP rules document', { 'NCP spec': ['txt', 'docx'] });
  if (!ncpUri) return undefined;
  const apiTitle = await askText('API title', 'Core Banking API');
  if (!apiTitle) return undefined;
  const apiVersion = await askText(
    'API version (info.version — the Swagger version itself is locked to 2.0)',
    '1.0.0',
  );
  if (!apiVersion) return undefined;
  const basePath = await askText('basePath for the API', '/api/v1', validateBasePath);
  if (!basePath) return undefined;

  const base = defaultOutputDir ?? vscode.workspace.workspaceFolders?.[0]?.uri.fsPath ?? '';
  const outputUri = await askText('Output path for swagger.json', base ? base + '/swagger.json' : 'swagger.json');
  if (!outputUri) return undefined;

  return { wsdlUri, ncpUri, outputUri, apiTitle, apiVersion, basePath, approvedOperations };
}

interface RepoInputs {
  outputDir: string;
  serviceName: string;
  envPrefix: string;
}

async function collectRepoInputs(): Promise<RepoInputs | undefined> {
  const outputDir = await pickFolder('Select the target folder for the generated repo');
  if (!outputDir) return undefined;
  const serviceName = await askText('Service name (README, package name, log lines)', 'Core-Banking-Service');
  if (!serviceName) return undefined;
  const envPrefix = await askText('Env-var prefix for backend HOST', 'COREBANKING', validateEnvPrefix);
  if (!envPrefix) return undefined;
  return { outputDir, serviceName, envPrefix };
}

function errorMessage(error: unknown, action: string): string | undefined {
  if (error instanceof vscode.CancellationError) return undefined;
  return error instanceof CopilotUnavailableError
    ? error.message
    : `${action} failed: ${error instanceof Error ? error.message : String(error)}`;
}

function showError(error: unknown, action: string): void {
  const message = errorMessage(error, action);
  if (message) void vscode.window.showErrorMessage(message);
}

// ---------------------------------------------------------------------------
// Command bodies (shared by palette commands, the chat participant, and the
// Endpoints sidebar view)
// ---------------------------------------------------------------------------

function toSummaryEndpoints(approved: ApprovedOperation[]): SummaryEndpoint[] {
  return approved.map((a) => ({
    operationName: a.operationName,
    method: a.method,
    path: a.path,
    isPlaceholder: a.path.startsWith('/placeholder/'),
  }));
}

async function runSwaggerFlow(
  model?: vscode.LanguageModelChat,
  preset?: SwaggerInputsPreset,
): Promise<string | undefined> {
  const inputs = await collectSwaggerInputs(undefined, preset);
  if (!inputs) return undefined;
  const summary = await vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title: 'SDLC: Generating Swagger 2.0', cancellable: true },
    (progress, token) => runSwaggerAgent(inputs, progress, token, model),
  );
  showSummaryPanel({
    title: 'Swagger 2.0 Generated',
    swaggerPath: inputs.outputUri,
    endpoints: toSummaryEndpoints(inputs.approvedOperations),
    notes: [summary],
  });
  return `swagger.json written to ${inputs.outputUri} and verified against your approved endpoints. ${summary}`;
}

async function runRepoFlow(): Promise<string | undefined> {
  const swaggerUri = await pickFile('Select the version-locked swagger.json', { Swagger: ['json'] });
  if (!swaggerUri) return undefined;
  const repo = await collectRepoInputs();
  if (!repo) return undefined;
  const written = await vscode.window.withProgress(
    { location: vscode.ProgressLocation.Notification, title: 'SDLC: Generating service repo (0 Copilot tokens)' },
    () => writeRepoFromSwagger({ swaggerUri, ...repo }),
  );
  showSummaryPanel({
    title: 'Service Repo Generated',
    outputDir: repo.outputDir,
    endpoints: [],
    repoFiles: written,
    notes: ['Run "npm install && npm test" in service/lambda-functions.'],
  });
  return `Service repo generated: ${written.length} files in ${repo.outputDir}. Run "npm install && npm test" in service/lambda-functions.`;
}

async function runEndToEndFlow(
  model?: vscode.LanguageModelChat,
  preset?: SwaggerInputsPreset,
): Promise<string | undefined> {
  const repo = await collectRepoInputs();
  if (!repo) return undefined;
  const inputs = await collectSwaggerInputs(repo.outputDir, preset);
  if (!inputs) return undefined;
  const result = await vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Notification,
      title: 'SDLC: WSDL + NCP -> Swagger 2.0 -> Service Repo',
      cancellable: true,
    },
    async (progress, token) => {
      const summary = await runSwaggerAgent(inputs, progress, token, model);
      progress.report({ message: 'Rendering service repo from swagger.json…' });
      const written = await writeRepoFromSwagger({ swaggerUri: inputs.outputUri, ...repo });
      return { summary, written };
    },
  );
  showSummaryPanel({
    title: 'End-to-End Generation Complete',
    swaggerPath: inputs.outputUri,
    outputDir: repo.outputDir,
    endpoints: toSummaryEndpoints(inputs.approvedOperations),
    repoFiles: result.written,
    notes: [result.summary],
  });
  return `End-to-end complete: swagger.json (verified) + ${result.written.length} repo files in ${repo.outputDir}. ${result.summary}`;
}

async function generateSwaggerCommand(): Promise<void> {
  try {
    const msg = await runSwaggerFlow();
    if (msg) void vscode.window.showInformationMessage(msg);
  } catch (error) {
    showError(error, 'Swagger generation');
  }
}

async function generateServiceCommand(): Promise<void> {
  try {
    const msg = await runRepoFlow();
    if (msg) void vscode.window.showInformationMessage(msg);
  } catch (error) {
    showError(error, 'Service generation');
  }
}

async function endToEndCommand(): Promise<void> {
  try {
    const msg = await runEndToEndFlow();
    if (msg) void vscode.window.showInformationMessage(msg);
  } catch (error) {
    showError(error, 'End-to-end generation');
  }
}

// ---------------------------------------------------------------------------
// Endpoints sidebar view — commands
// ---------------------------------------------------------------------------

async function loadWsdlForApprovalCommand(): Promise<void> {
  try {
    const wsdlUri = await pickFile('Select the WSDL file', { 'WSDL/XSD': ['wsdl', 'xsd', 'xml'] });
    if (!wsdlUri) return;
    const count = await endpointProvider.loadWsdl(wsdlUri);
    void vscode.window.showInformationMessage(
      `Loaded ${count} operation(s) from the WSDL. Click a row in the Endpoints view to approve its REST path + method, then use "Generate from Approved Endpoints".`,
    );
  } catch (error) {
    showError(error, 'Loading WSDL');
  }
}

/** Invoked either by clicking a row (arg = operationName) or its context-menu item (arg = EndpointItem). */
async function editEndpointCommand(arg: string | EndpointItem): Promise<void> {
  const operationName = typeof arg === 'string' ? arg : arg.operationName;
  const current = endpointProvider.getEndpoint(operationName);
  if (!current) return;

  const path = await vscode.window.showInputBox({
    title: `REST path for WSDL operation "${operationName}"`,
    prompt: 'This value is used EXACTLY as entered — no re-casing, no invented segments.',
    value: current.path,
    ignoreFocusOut: true,
    validateInput: validateBasePath,
  });
  if (path === undefined) return;

  const methodPick = await vscode.window.showQuickPick(
    (['post', 'get', 'put', 'delete', 'patch'] as const).map((m) => ({
      label: m.toUpperCase(),
      description: m === current.method ? 'current' : undefined,
      method: m,
    })),
    { title: `HTTP method for "${operationName}" (${path})`, ignoreFocusOut: true },
  );
  if (!methodPick) return;

  endpointProvider.setEndpoint(operationName, path, methodPick.method);
}

async function generateFromEndpointsViewCommand(): Promise<void> {
  const wsdlUri = endpointProvider.getWsdlUri();
  if (!wsdlUri || !endpointProvider.hasOperations()) {
    void vscode.window.showWarningMessage(
      'Load a WSDL into the Endpoints view first (the download-icon button in the view\'s toolbar).',
    );
    return;
  }
  if (!endpointProvider.allApproved()) {
    void vscode.window.showWarningMessage(
      `${endpointProvider.approvedCount()}/${endpointProvider.getApprovals().length} endpoints approved — click every row in the Endpoints view to approve it before generating.`,
    );
    return;
  }

  const flowPick = await vscode.window.showQuickPick(
    [
      { label: 'Swagger 2.0 only', description: '2–3 Copilot requests', flow: 'swagger' as const },
      { label: 'End-to-end (Swagger + service repo)', description: 'Copilot + 0-token repo scaffold', flow: 'endToEnd' as const },
    ],
    { title: 'Generate from the approved endpoints', ignoreFocusOut: true },
  );
  if (!flowPick) return;

  const preset: SwaggerInputsPreset = { wsdlUri, approvedOperations: endpointProvider.getApprovals() };
  try {
    const msg =
      flowPick.flow === 'swagger' ? await runSwaggerFlow(undefined, preset) : await runEndToEndFlow(undefined, preset);
    if (msg) void vscode.window.showInformationMessage(msg);
  } catch (error) {
    showError(error, 'Generation');
  }
}

// ---------------------------------------------------------------------------
// Chat participant: @sdlc  ("build a swagger based on WSDL and NCP doc")
// ---------------------------------------------------------------------------

type FlowName = 'swagger' | 'repo' | 'endToEnd';

export function detectFlow(command: string | undefined, prompt: string): FlowName {
  if (command === 'swagger' || command === 'repo' || command === 'endToEnd') return command;
  const p = prompt.toLowerCase();
  if (/end.?to.?end|full|everything/.test(p)) return 'endToEnd';
  const wantsRepo = /\brepo\b|\bcode\b|lambda|service/.test(p);
  const wantsSwagger = /swagger|wsdl|ncp|spec/.test(p);
  if (wantsRepo && !wantsSwagger) return 'repo';
  if (wantsRepo && wantsSwagger) return 'endToEnd';
  return 'swagger';
}

async function chatHandler(
  request: vscode.ChatRequest,
  _context: vscode.ChatContext,
  stream: vscode.ChatResponseStream,
  _token: vscode.CancellationToken,
): Promise<void> {
  const flow = detectFlow(request.command, request.prompt);
  const intro: Record<FlowName, string> = {
    swagger:
      'Generating a **version-locked Swagger 2.0** from your WSDL + NCP. I will ask you to pick the files and **approve every endpoint** — Copilot never chooses endpoints.',
    repo: 'Generating the Lambda service repo from an existing swagger.json — fully deterministic, 0 Copilot tokens.',
    endToEnd:
      'Running **end-to-end**: WSDL + NCP -> verified Swagger 2.0 -> service repo. I will ask you to pick files and **approve every endpoint** first.',
  };
  stream.markdown(intro[flow] + '\n\nFollow the input dialogs…\n');

  try {
    let result: string | undefined;
    if (flow === 'swagger') result = await runSwaggerFlow(request.model);
    else if (flow === 'repo') result = await runRepoFlow();
    else result = await runEndToEndFlow(request.model);

    stream.markdown(result ? '\n✅ ' + result + '\n' : '\nCancelled.\n');
  } catch (error) {
    const msg = errorMessage(error, 'Generation');
    stream.markdown(msg ? '\n❌ ' + msg + '\n' : '\nCancelled.\n');
  }
}

export function deactivate(): void {
  // All disposables are on context.subscriptions.
}
