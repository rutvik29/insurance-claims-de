/**
 * Deterministic WSDL/XSD parser built on fast-xml-parser.
 *
 * GUARANTEES:
 *  - Every operation, element, and field name is copied byte-for-byte from
 *    the source XML. Nothing is renamed, re-cased, or invented.
 *  - Unknown XSD types throw (UnknownXsdTypeError) instead of being guessed.
 *  - No LLM involvement anywhere in this module.
 *
 * Supported shape: document/literal (wrapped) WSDL 1.1 with an inline
 * <xsd:schema> in <wsdl:types> — the dominant style in legacy banking SOAP.
 */

import { XMLParser } from 'fast-xml-parser';
import { isXsdPrimitive, mapXsdType } from './xsdTypeMapper';

/* eslint-disable @typescript-eslint/no-explicit-any */
type XmlNode = Record<string, any>;

export interface XsdConstraints {
  maxLength?: number;
  minLength?: number;
  pattern?: string;
  enum?: string[];
}

export interface WsdlField {
  /** Exact field name from the XSD — never modified. */
  name: string;
  /** Original XSD type local name (e.g. "string", "decimal", or a complex type name). */
  xsdType: string;
  /** Swagger primitive type; 'object' when the field references a named complex type. */
  swaggerType: 'string' | 'number' | 'integer' | 'boolean' | 'object';
  swaggerFormat?: string;
  required: boolean;
  isArray: boolean;
  /** Set when the field's type is a named complexType — points into ParsedWsdl.types. */
  complexRef?: string;
  constraints: XsdConstraints;
}

export interface WsdlMessagePart {
  /** Exact element name from the schema (becomes the Swagger definition name). */
  elementName: string;
  fields: WsdlField[];
}

export interface WsdlOperation {
  /** Exact operation name from <wsdl:operation>. */
  name: string;
  input: WsdlMessagePart;
  output: WsdlMessagePart;
}

export interface ParsedWsdl {
  serviceName: string;
  targetNamespace: string;
  operations: WsdlOperation[];
  /** Named complex types referenced by message fields (definition name -> fields). */
  types: Record<string, WsdlField[]>;
}

export class WsdlParseError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'WsdlParseError';
  }
}

const localName = (qname: string): string => {
  const idx = qname.indexOf(':');
  return idx === -1 ? qname : qname.substring(idx + 1);
};

const toArray = <T>(value: T | T[] | undefined): T[] =>
  value === undefined ? [] : Array.isArray(value) ? value : [value];

function extractConstraints(restriction: XmlNode | undefined): XsdConstraints {
  const constraints: XsdConstraints = {};
  if (!restriction) {
    return constraints;
  }
  if (restriction.maxLength?.['@_value'] !== undefined) {
    constraints.maxLength = Number(restriction.maxLength['@_value']);
  }
  if (restriction.minLength?.['@_value'] !== undefined) {
    constraints.minLength = Number(restriction.minLength['@_value']);
  }
  if (restriction.pattern?.['@_value'] !== undefined) {
    constraints.pattern = String(restriction.pattern['@_value']);
  }
  const enums = toArray<XmlNode>(restriction.enumeration)
    .map((e) => e['@_value'])
    .filter((v): v is string => v !== undefined)
    .map(String);
  if (enums.length > 0) {
    constraints.enum = enums;
  }
  return constraints;
}

export function parseWsdl(xml: string): ParsedWsdl {
  const parser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: '@_',
    removeNSPrefix: true, // strips wsdl:/xsd: from TAG names only; attribute VALUES stay intact
    parseAttributeValue: false,
    parseTagValue: false,
  });

  const root: XmlNode = parser.parse(xml);
  const defs: XmlNode | undefined = root.definitions;
  if (!defs) {
    throw new WsdlParseError('Not a valid WSDL 1.1 document: missing <wsdl:definitions>.');
  }

  const targetNamespace: string = String(defs['@_targetNamespace'] ?? '');

  // ---- 1. Index schema elements and named complex types --------------------
  const elementsByName = new Map<string, XmlNode>();
  const complexTypesByName = new Map<string, XmlNode>();

  for (const schema of toArray<XmlNode>(defs.types?.schema)) {
    for (const el of toArray<XmlNode>(schema.element)) {
      if (el['@_name']) {
        elementsByName.set(String(el['@_name']), el);
      }
    }
    for (const ct of toArray<XmlNode>(schema.complexType)) {
      if (ct['@_name']) {
        complexTypesByName.set(String(ct['@_name']), ct);
      }
    }
  }

  // ---- 2. Field extraction --------------------------------------------------
  const referencedComplexTypes = new Set<string>();

  const fieldFromXsdElement = (el: XmlNode): WsdlField => {
    const name = el['@_name'];
    if (!name) {
      throw new WsdlParseError('Encountered an <xsd:element> without a name attribute.');
    }
    const required = el['@_minOccurs'] !== '0';
    const isArray = el['@_maxOccurs'] === 'unbounded' || Number(el['@_maxOccurs']) > 1;

    // Case A: inline <xsd:simpleType><xsd:restriction base="...">
    const restriction: XmlNode | undefined = el.simpleType?.restriction;
    if (restriction) {
      const base = localName(String(restriction['@_base'] ?? 'string'));
      const primitive = mapXsdType(base);
      return {
        name: String(name),
        xsdType: base,
        swaggerType: primitive.type,
        ...(primitive.format !== undefined ? { swaggerFormat: primitive.format } : {}),
        required,
        isArray,
        constraints: extractConstraints(restriction),
      };
    }

    // Case B: @type attribute — primitive or named complex type
    const typeAttr = el['@_type'];
    if (typeAttr !== undefined) {
      const typeLocal = localName(String(typeAttr));
      if (isXsdPrimitive(typeLocal)) {
        const primitive = mapXsdType(typeLocal);
        return {
          name: String(name),
          xsdType: typeLocal,
          swaggerType: primitive.type,
          ...(primitive.format !== undefined ? { swaggerFormat: primitive.format } : {}),
          required,
          isArray,
          constraints: {},
        };
      }
      if (complexTypesByName.has(typeLocal)) {
        referencedComplexTypes.add(typeLocal);
        return {
          name: String(name),
          xsdType: typeLocal,
          swaggerType: 'object',
          required,
          isArray,
          complexRef: typeLocal,
          constraints: {},
        };
      }
      throw new WsdlParseError(
        `Field "${String(name)}" references type "${typeLocal}" which is neither an XSD primitive nor a complexType declared in this document.`,
      );
    }

    throw new WsdlParseError(
      `Field "${String(name)}" has neither a type attribute nor an inline simpleType restriction.`,
    );
  };

  const fieldsFromComplexType = (ct: XmlNode, ownerLabel: string): WsdlField[] => {
    const sequence: XmlNode | undefined = ct.sequence;
    if (!sequence) {
      throw new WsdlParseError(`complexType for "${ownerLabel}" has no <xsd:sequence>.`);
    }
    return toArray<XmlNode>(sequence.element).map(fieldFromXsdElement);
  };

  const resolveElementToPart = (elementLocalName: string): WsdlMessagePart => {
    const el = elementsByName.get(elementLocalName);
    if (!el) {
      throw new WsdlParseError(`Schema element "${elementLocalName}" not found in <wsdl:types>.`);
    }
    if (el.complexType) {
      return { elementName: elementLocalName, fields: fieldsFromComplexType(el.complexType, elementLocalName) };
    }
    const typeAttr = el['@_type'];
    if (typeAttr !== undefined) {
      const typeLocal = localName(String(typeAttr));
      const ct = complexTypesByName.get(typeLocal);
      if (ct) {
        return { elementName: elementLocalName, fields: fieldsFromComplexType(ct, elementLocalName) };
      }
    }
    throw new WsdlParseError(`Element "${elementLocalName}" does not resolve to a complexType.`);
  };

  // ---- 3. Messages -----------------------------------------------------------
  const messageToElement = new Map<string, string>();
  for (const msg of toArray<XmlNode>(defs.message)) {
    const msgName = msg['@_name'];
    const part = toArray<XmlNode>(msg.part)[0];
    if (msgName && part?.['@_element']) {
      messageToElement.set(String(msgName), localName(String(part['@_element'])));
    }
  }

  // ---- 4. Operations ---------------------------------------------------------
  const operations: WsdlOperation[] = [];
  for (const portType of toArray<XmlNode>(defs.portType)) {
    for (const op of toArray<XmlNode>(portType.operation)) {
      const opName = op['@_name'];
      if (!opName) {
        throw new WsdlParseError('Encountered a <wsdl:operation> without a name.');
      }
      const inputMsg = localName(String(op.input?.['@_message'] ?? ''));
      const outputMsg = localName(String(op.output?.['@_message'] ?? ''));
      const inputElement = messageToElement.get(inputMsg);
      const outputElement = messageToElement.get(outputMsg);
      if (!inputElement || !outputElement) {
        throw new WsdlParseError(
          `Operation "${String(opName)}" references message(s) that could not be resolved (input="${inputMsg}", output="${outputMsg}").`,
        );
      }
      operations.push({
        name: String(opName),
        input: resolveElementToPart(inputElement),
        output: resolveElementToPart(outputElement),
      });
    }
  }

  if (operations.length === 0) {
    throw new WsdlParseError('No operations found in any <wsdl:portType>.');
  }

  // ---- 5. Referenced named complex types ---------------------------------------
  const types: Record<string, WsdlField[]> = {};
  for (const typeName of referencedComplexTypes) {
    const ct = complexTypesByName.get(typeName);
    if (ct) {
      types[typeName] = fieldsFromComplexType(ct, typeName);
    }
  }

  const serviceName = String(defs.service?.['@_name'] ?? defs['@_name'] ?? 'UnknownService');

  return { serviceName, targetNamespace, operations, types };
}
