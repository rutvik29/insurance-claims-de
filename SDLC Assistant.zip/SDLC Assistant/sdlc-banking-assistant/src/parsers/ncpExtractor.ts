/**
 * Deterministic NCP business-rules extractor.
 *
 * A versioned registry of regular expressions pulls mandatory/optional headers,
 * field-level constraints, and error codes out of NCP text. Zero LLM tokens are
 * spent here; only the (small) matched rules ever reach a prompt.
 *
 * Expected NCP line formats (extend the registry, with tests, for new formats):
 *   HEADER: X-Channel-Id (Mandatory) - Identifies the originating channel
 *   FIELD: accountNumber MAXLENGTH 12
 *   FIELD: accountNumber PATTERN ^[0-9]{6,12}$
 *   ERROR: E1001 - Invalid account number
 */

export interface NcpHeaderRule {
  /** Exact header name from the NCP document — never modified. */
  name: string;
  required: boolean;
  description: string;
}

export type NcpFieldRuleKind = 'MAXLENGTH' | 'MINLENGTH' | 'PATTERN' | 'ENUM';

export interface NcpFieldRule {
  /** Exact field name from the NCP document. */
  field: string;
  rule: NcpFieldRuleKind;
  value: string;
}

export interface NcpErrorCode {
  code: string;
  description: string;
}

export interface NcpRules {
  headers: NcpHeaderRule[];
  fieldRules: NcpFieldRule[];
  errorCodes: NcpErrorCode[];
}

/** Registry version — bump when patterns change so cached extractions invalidate. */
export const NCP_PATTERN_REGISTRY_VERSION = '1.0.0';

const HEADER_PATTERN =
  /^HEADER\s*:\s*([A-Za-z0-9._-]+)\s*\((Mandatory|Optional)\)\s*(?:[-–—]\s*(.*))?$/gim;

const FIELD_PATTERN =
  /^FIELD\s*:\s*([A-Za-z0-9._]+)\s+(MAXLENGTH|MINLENGTH|PATTERN|ENUM)\s+(.+)$/gim;

const ERROR_PATTERN = /^ERROR\s*:\s*([A-Z][0-9]{3,6})\s*[-–—]\s*(.*)$/gim;

export function extractNcpRules(text: string): NcpRules {
  const headers: NcpHeaderRule[] = [];
  const seenHeaders = new Set<string>();
  for (const match of text.matchAll(HEADER_PATTERN)) {
    const name = match[1];
    if (name === undefined || seenHeaders.has(name)) {
      continue;
    }
    seenHeaders.add(name);
    headers.push({
      name,
      required: match[2]?.toLowerCase() === 'mandatory',
      description: (match[3] ?? '').trim(),
    });
  }

  const fieldRules: NcpFieldRule[] = [];
  for (const match of text.matchAll(FIELD_PATTERN)) {
    const field = match[1];
    const rule = match[2]?.toUpperCase() as NcpFieldRuleKind | undefined;
    const value = match[3]?.trim();
    if (field !== undefined && rule !== undefined && value !== undefined) {
      fieldRules.push({ field, rule, value });
    }
  }

  const errorCodes: NcpErrorCode[] = [];
  const seenCodes = new Set<string>();
  for (const match of text.matchAll(ERROR_PATTERN)) {
    const code = match[1];
    if (code === undefined || seenCodes.has(code)) {
      continue;
    }
    seenCodes.add(code);
    errorCodes.push({ code, description: (match[2] ?? '').trim() });
  }

  return { headers, fieldRules, errorCodes };
}
