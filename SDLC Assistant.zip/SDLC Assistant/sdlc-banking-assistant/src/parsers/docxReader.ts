/**
 * Thin deterministic wrapper around mammoth for NCP .docx ingestion.
 * Returns raw text only — all rule extraction happens in ncpExtractor.ts.
 */

import * as mammoth from 'mammoth';

export async function extractDocxText(buffer: Buffer): Promise<string> {
  const result = await mammoth.extractRawText({ buffer });
  return result.value;
}
