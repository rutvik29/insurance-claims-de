/**
 * Deterministic XSD -> Swagger 2.0 primitive type mapping.
 * Swagger 2.0 uses JSON Schema draft-04 semantics (type + format).
 * This table is exhaustive for the XSD built-ins used in core-banking WSDLs;
 * unknown types fail loudly rather than being guessed.
 */

export interface SwaggerPrimitive {
  readonly type: 'string' | 'number' | 'integer' | 'boolean';
  readonly format?: string;
}

const XSD_TO_SWAGGER: Readonly<Record<string, SwaggerPrimitive>> = {
  string: { type: 'string' },
  normalizedString: { type: 'string' },
  token: { type: 'string' },
  anyURI: { type: 'string', format: 'uri' },
  base64Binary: { type: 'string', format: 'byte' },
  hexBinary: { type: 'string' },
  date: { type: 'string', format: 'date' },
  dateTime: { type: 'string', format: 'date-time' },
  time: { type: 'string' },
  duration: { type: 'string' },
  gYear: { type: 'string' },
  gYearMonth: { type: 'string' },
  boolean: { type: 'boolean' },
  decimal: { type: 'number', format: 'double' },
  float: { type: 'number', format: 'float' },
  double: { type: 'number', format: 'double' },
  int: { type: 'integer', format: 'int32' },
  integer: { type: 'integer', format: 'int64' },
  nonNegativeInteger: { type: 'integer', format: 'int64' },
  positiveInteger: { type: 'integer', format: 'int64' },
  long: { type: 'integer', format: 'int64' },
  short: { type: 'integer', format: 'int32' },
  byte: { type: 'integer', format: 'int32' },
  unsignedInt: { type: 'integer', format: 'int64' },
  unsignedLong: { type: 'integer', format: 'int64' },
  unsignedShort: { type: 'integer', format: 'int32' },
};

export class UnknownXsdTypeError extends Error {
  readonly xsdType: string;
  constructor(xsdType: string) {
    super(
      `Unknown XSD type "${xsdType}". Refusing to guess a Swagger mapping. ` +
        `Add it to XSD_TO_SWAGGER in xsdTypeMapper.ts after review.`,
    );
    this.name = 'UnknownXsdTypeError';
    this.xsdType = xsdType;
  }
}

/** Maps an XSD local type name (namespace prefix already stripped) to Swagger. */
export function mapXsdType(xsdLocalType: string): SwaggerPrimitive {
  const mapped = XSD_TO_SWAGGER[xsdLocalType];
  if (!mapped) {
    throw new UnknownXsdTypeError(xsdLocalType);
  }
  return mapped;
}

/** True if the local type name is a known XSD built-in primitive. */
export function isXsdPrimitive(xsdLocalType: string): boolean {
  return Object.prototype.hasOwnProperty.call(XSD_TO_SWAGGER, xsdLocalType);
}
