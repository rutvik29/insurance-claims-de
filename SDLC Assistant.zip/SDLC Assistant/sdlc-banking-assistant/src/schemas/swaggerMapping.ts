/**
 * Zod contract for the ONLY thing the LLM is allowed to produce:
 * a small mapping JSON assigning REST paths/methods to WSDL operations.
 * Everything else in the Swagger document is derived deterministically.
 */

import { z } from 'zod';

export const OperationMappingSchema = z
  .object({
    /** Must EXACTLY match an operation name from the parsed WSDL (verified in the generator). */
    operationName: z.string().min(1),
    path: z
      .string()
      .regex(/^\/[A-Za-z0-9\-._~/{}]*$/, 'path must start with / and contain only URL-safe characters'),
    method: z.enum(['get', 'post', 'put', 'delete', 'patch']),
    summary: z.string().max(300).optional(),
  })
  .strict();

export const SwaggerMappingSchema = z
  .object({
    info: z
      .object({
        title: z.string().min(1).max(200),
        version: z.string().min(1).max(50),
        description: z.string().max(1000).optional(),
      })
      .strict(),
    basePath: z.string().regex(/^\//, 'basePath must start with /'),
    operations: z.array(OperationMappingSchema).min(1),
  })
  .strict();

export type SwaggerMapping = z.infer<typeof SwaggerMappingSchema>;
export type OperationMapping = z.infer<typeof OperationMappingSchema>;

/** Parses and validates a raw (possibly LLM-produced) value into a SwaggerMapping. */
export function validateMapping(raw: unknown): SwaggerMapping {
  return SwaggerMappingSchema.parse(raw);
}
