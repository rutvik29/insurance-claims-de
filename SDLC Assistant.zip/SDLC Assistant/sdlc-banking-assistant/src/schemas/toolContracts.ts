/**
 * Zod contracts for every Language Model Tool boundary.
 * All tool inputs cross one of these schemas before any work happens.
 */

import { z } from 'zod';
import { SwaggerMappingSchema } from './swaggerMapping';

export const ReadWsdlInputSchema = z
  .object({
    fileUri: z.string().min(1),
  })
  .strict();
export type ReadWsdlInput = z.infer<typeof ReadWsdlInputSchema>;

export const QueryNcpInputSchema = z
  .object({
    fileUri: z.string().min(1),
  })
  .strict();
export type QueryNcpInput = z.infer<typeof QueryNcpInputSchema>;

export const GenerateSwaggerInputSchema = z
  .object({
    wsdlUri: z.string().min(1),
    ncpUri: z.string().min(1),
    outputUri: z.string().min(1),
    mapping: SwaggerMappingSchema,
  })
  .strict();
export type GenerateSwaggerInput = z.infer<typeof GenerateSwaggerInputSchema>;

export const GenerateArtifactsInputSchema = z
  .object({
    swaggerUri: z.string().min(1),
    outputDir: z.string().min(1),
    serviceName: z.string().min(1).max(100),
    envPrefix: z.string().regex(/^[A-Z][A-Z0-9]*$/, 'UPPERCASE alphanumeric, e.g. MORTGAGELOANSTATEMENT'),
  })
  .strict();
export type GenerateArtifactsInput = z.infer<typeof GenerateArtifactsInputSchema>;
